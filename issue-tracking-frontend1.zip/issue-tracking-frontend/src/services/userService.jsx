import axios from "axios";

export const USER_API_URL = '/api/users';

/**
 * Register a new user
 * Calls POST /api/users/register
 */
export const registerUser = async (user) => {
    try {
        const response = await axios.post(`${USER_API_URL}/register`, {
            name: user.name,
            emailId: user.emailId,
            password: user.password,
            role: user.role, // 'PROJECT_OWNER' or 'ASSIGNEE'
            profileImage: user.profileImage
        });
        return response.data;
    } catch (error) {
        console.error('Error Registering the User - ', error);
        const serverMsg = error.response?.data?.errorMessage || error.response?.data?.message || (typeof error.response?.data === 'string' ? error.response.data : error.message);
        throw new Error(serverMsg || 'An error occurred during registration.');
    }
};

/**
 * Login user
 * Calls POST /api/users/login?name=&emailId=...&password=...&role=...
 */
export const login = async (emailId, password, role) => {
    try {
        const normalizedRole = role ? role.toUpperCase().replace(/\s+/g, '_') : '';
        const response = await axios.post(
            `${USER_API_URL}/login?name=&emailId=${encodeURIComponent(emailId)}&password=${encodeURIComponent(password)}&role=${encodeURIComponent(normalizedRole)}`
        );
        return { success: true, user: response.data };
    } catch (error) {
        console.error('Error Logging in the User - ', error);
        const serverMsg = error.response?.data?.errorMessage || error.response?.data?.message || (typeof error.response?.data === 'string' ? error.response.data : 'Invalid credentials. Please try again.');
        return { success: false, user: null, error: serverMsg };
    }
};

/**
 * Fetch all users
 * Calls GET /api/users/all
 */
export const getAllUsers = async () => {
    try {
        const response = await axios.get(`${USER_API_URL}/all`);
        return response.data;
    } catch (error) {
        console.error('Error fetching all users - ', error);
        if (error.response?.data?.errorMessage?.includes('No users found')) {
            return [];
        }
        throw error;
    }
};

/**
 * Fetch a single user by ID
 * Calls GET /api/users/{userId}
 */
export const getUserById = async (userId) => {
    try {
        const response = await axios.get(`${USER_API_URL}/${userId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching user by ID - ', error);
        throw error;
    }
};

/**
 * Fetch issues assigned to a specific user
 * Calls GET /api/users/{userId}/issues
 */
export const getIssuesByUserId = async (userId) => {
    try {
        const response = await axios.get(`${USER_API_URL}/${userId}/issues`);
        return response.data;
    } catch (error) {
        console.error('Error fetching issues by user ID - ', error);
        if (error.response?.data?.errorMessage?.includes('no issues')) {
            return [];
        }
        return [];
    }
};

