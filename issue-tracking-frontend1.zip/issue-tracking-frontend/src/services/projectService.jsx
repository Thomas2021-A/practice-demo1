import axios from "axios";

export const PROJECT_API_URL = '/api/projects';

/**
 * Fetch all projects
 * Calls GET /api/projects
 */
export const getAllProjects = async () => {
    try {
        const response = await axios.get(PROJECT_API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching all projects - ', error);
        if (error.response?.data?.errorMessage?.includes('No projects found')) {
            return [];
        }
        throw error;
    }
};

/**
 * Fetch projects owned by a specific project owner
 * Calls GET /api/projects/owner/{ownerId}
 */
export const getProjectsByOwner = async (ownerId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/owner/${ownerId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching projects by owner - ', error);
        if (error.response?.data?.errorMessage?.includes('No projects found') || error.response?.status === 404) {
            return [];
        }
        throw error;
    }
};

/**
 * Fetch a single project by ID
 * Calls GET /api/projects/{projectId}
 */
export const getProjectById = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching project by ID - ', error);
        throw error;
    }
};

/**
 * Create a new project
 * Calls POST /api/projects
 */
export const createProject = async (project) => {
    try {
        const response = await axios.post(PROJECT_API_URL, project);
        return response.data;
    } catch (error) {
        console.error('Error creating project - ', error);
        const serverMsg = error.response?.data?.errorMessage || error.response?.data?.message || (typeof error.response?.data === 'string' ? error.response.data : error.message);
        throw new Error(serverMsg || 'Failed to create project.');
    }
};

/**
 * Update an existing project
 * Calls PUT /api/projects/{id}
 */
export const updateProject = async (id, project) => {
    try {
        const response = await axios.put(`${PROJECT_API_URL}/${id}`, project);
        return response.data;
    } catch (error) {
        console.error('Error updating project - ', error);
        const serverMsg = error.response?.data?.errorMessage || error.response?.data?.message || 'Failed to update project.';
        throw new Error(serverMsg);
    }
};

/**
 * Delete a project
 * Calls DELETE /api/projects/{id}
 */
export const deleteProject = async (id) => {
    try {
        const response = await axios.delete(`${PROJECT_API_URL}/${id}`);
        return response.data;
    } catch (error) {
        console.error('Error deleting project - ', error);
        const serverMsg = error.response?.data?.errorMessage || 'Failed to delete project.';
        throw new Error(serverMsg);
    }
};

/**
 * Fetch issues belonging to a specific project
 * Calls GET /api/projects/{projectId}/issues
 */
export const getIssuesByProjectId = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}/issues`);
        return response.data;
    } catch (error) {
        console.error('Error fetching project issues - ', error);
        if (error.response?.data?.errorMessage?.includes('No issues discovered') || error.response?.status === 404) {
            return [];
        }
        return [];
    }
};
