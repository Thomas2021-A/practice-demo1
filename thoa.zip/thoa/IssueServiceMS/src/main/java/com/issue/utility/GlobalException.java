package com.issue.utility;



import java.time.LocalDateTime;
import java.util.stream.Collectors;

import com.issue.utility.ErrorInfo;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.issue.exception.IssueException;

@RestControllerAdvice
public class GlobalException {
	@ExceptionHandler(value = MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorInfo> handleValidationException(MethodArgumentNotValidException exception){
		ErrorInfo errorInfo = new ErrorInfo();
		String message = exception.getBindingResult()
				.getAllErrors()
				.stream()
				.map(error -> error.getDefaultMessage())
				.collect((Collectors.joining(", ")));
		
		errorInfo.setErrorMessage(message);
		errorInfo.setErrorCode(HttpStatus.BAD_REQUEST.value());
		errorInfo.setTimestamp(LocalDateTime.now());
		
		return new ResponseEntity(errorInfo, HttpStatus.BAD_REQUEST);
		
	}
	@ExceptionHandler(value=IssueException.class)
	public ResponseEntity<ErrorInfo> handleOrderException(IssueException exception){
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorMessage(exception.getMessage());
		errorInfo.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		errorInfo.setTimestamp(LocalDateTime.now());
		
		return new ResponseEntity<>(errorInfo, HttpStatus.INTERNAL_SERVER_ERROR);
	
	}
}
