package com.user.client;
 
import java.util.List;

 
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
 
import com.user.model.IssueDTO;
 
 
@FeignClient(name = "IssueServiceMS", url = "http://localhost:7004/api/issues")
public interface IssueFeign {
	@GetMapping("/assignee/{assigneeId}")
	public List<IssueDTO> getIssuesByAssigneeId(@PathVariable Integer assigneeId) throws Exception;
}