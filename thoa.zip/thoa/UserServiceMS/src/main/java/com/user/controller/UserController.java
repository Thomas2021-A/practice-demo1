package com.user.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
 
import com.user.exception.UserException;
import com.user.model.IssueDTO;
import com.user.model.UserDTO;
import com.user.service.UserService;
 
import jakarta.validation.Valid;
 
@RestController
@RequestMapping("/api/users")
public class UserController {
	@Autowired
	private UserService userService;
	
	
	/*
	 * @GetMapping("/{userId}/issues") public ResponseEntity<List<IssueDTO>>
	 * getIssuesByUserId(@PathVariable Integer userId) throws Exception {
	 * List<IssueDTO> issues = userService.getIssuesByUserId(userId); return new
	 * ResponseEntity<>(issues, HttpStatus.OK); }
	 * 
	 * 
	 * 
	 */
	
	
	
	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@Valid @RequestBody UserDTO userDTO) throws UserException {
		String message = userService.registerUser(userDTO);
		return new ResponseEntity<>(message, HttpStatus.CREATED);
	}
	@PostMapping("/login")
	public ResponseEntity<UserDTO> loginUser(@RequestParam String name, @RequestParam String emailId, @RequestParam String password, @RequestParam String role) throws UserException {
		UserDTO userDTO= userService.loginUser(name, emailId, password, role);
		return new ResponseEntity<>(userDTO, HttpStatus.OK);
	}
	@GetMapping("/{userId}")
	public ResponseEntity<UserDTO> getUserById(@PathVariable Integer userId) throws UserException {
		UserDTO userDTO = userService.getUserById(userId);
		return new ResponseEntity<>(userDTO, HttpStatus.OK);
	}
	@GetMapping("/all")
	public ResponseEntity<List<UserDTO>> getAllUsers() throws UserException {
		List<UserDTO> users = userService.getAllUsers();
		return new ResponseEntity<>(users, HttpStatus.OK);
	}
	@PutMapping("/{userId}")
	public ResponseEntity<String> updateUser(@PathVariable Integer userId, @Valid @RequestBody UserDTO userDTO) throws UserException {
		String message = userService.updateUser(userId, userDTO);
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	@DeleteMapping("/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable Integer userId) throws UserException {
		String message = userService.deleteUser(userId);
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	
	@GetMapping("/{userId}/issues")
	public ResponseEntity<List<IssueDTO>> getIssuesByUserId(@PathVariable Integer userId) throws Exception {
	    List<IssueDTO> issues = userService.getIssuesByUserId(userId);
	    return new ResponseEntity<>(issues, HttpStatus.OK);
	}
	 
	@GetMapping("/username/{username}/issues")
	public ResponseEntity<List<IssueDTO>> getIssuesByUsername(@PathVariable String username) throws Exception {
	    List<IssueDTO> issues = userService.getIssuesByUsername(username);
	    return new ResponseEntity<>(issues, HttpStatus.OK);
	}

	//Implement the following endpoints
		//registerUser()
		//loginUser()
		//getUserById()
		//getAllUsers()
		//updateUser()
		//deleteUser()
}