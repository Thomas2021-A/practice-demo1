package com.project.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.client.IssueFeign;
import com.project.entity.Project;
import com.project.exception.ProjectException;
import com.project.model.IssueDTO;
import com.project.model.ProjectDTO;
import com.project.repository.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ModelMapper mapper;
    
    
    @Autowired
    private IssueFeign issueFeign;
    
    
    @Override
	public List<IssueDTO> getIssuesByProjectId(Integer projectId) throws Exception {
	    List<IssueDTO> issues = null;
	    try {
	        issues = issueFeign.getIssuesByProjectId(projectId);
	        if (issues == null || issues.isEmpty()) {
	            throw new Exception("No issues found for the specified project ID.");
	        }
	    } catch (Exception exception) {
	        throw new Exception("Issue microservice call failed: " + exception.getMessage());
	    }
	    return issues;
	}
 
	@Override
	public List<IssueDTO> getIssuesByProjectName(String projectName) throws Exception {
	    // 1. Resolve project by name to find its unique database ID
	    com.project.entity.Project project = projectRepository.findByProjectName(projectName)
	            .orElseThrow(() -> new Exception("Project not found with name: " + projectName));
	            
	    List<IssueDTO> issues = null;
	    try {
	        // 2. Route the discovered ID through Feign communication lines
	        issues = issueFeign.getIssuesByProjectId(project.getId());
	        if (issues == null || issues.isEmpty()) {
	            throw new Exception("No issues found for project named: " + projectName);
	        }
	    } catch (Exception exception) {
	        throw new Exception("Issue microservice call failed: " + exception.getMessage());
	    }
	    return issues;
	}

    @Override
    public String createProject(ProjectDTO projectDTO) {
        Project project = new Project();
        mapper.map(projectDTO, project);
        project.setId(null);
        projectRepository.save(project);
        return "Project created successfully";
    }

    @Override
    public ProjectDTO getProjectById(Integer id) throws ProjectException {
        Optional<Project> optional = projectRepository.findById(id);
        Project project = optional.orElseThrow(
            () -> new ProjectException("Project not found with ID: " + id)
        );
        return mapper.map(project, ProjectDTO.class);
    }

    @Override
    public List<ProjectDTO> getAllProjects() throws ProjectException {
        List<Project> projects = projectRepository.findAll();

        if (projects.isEmpty()) {
            throw new ProjectException("No projects found in the database.");
        }

        List<ProjectDTO> projectDTOs = new ArrayList<>();
        for (Project project : projects) {
            projectDTOs.add(mapper.map(project, ProjectDTO.class));
        }
        return projectDTOs;
    }

    @Override
    public String updateProject(Integer id, ProjectDTO projectDTO)
            throws ProjectException {
        Optional<Project> optional = projectRepository.findById(id);
        Project project = optional.orElseThrow(
            () -> new ProjectException("Project not found with ID: " + id)
        );

        project.setProjectName(projectDTO.getProjectName());
        project.setProjectOwner(projectDTO.getProjectOwner());
        project.setStartDate(projectDTO.getStartDate());
        project.setEndDate(projectDTO.getEndDate());

        projectRepository.save(project);
        return "Project details updated successfully for Project ID: " + id;
    }

    @Override
    public String deleteProject(Integer id) throws ProjectException {
        Optional<Project> optional = projectRepository.findById(id);
        Project project = optional.orElseThrow(
            () -> new ProjectException("Project not found with ID: " + id)
        );

        projectRepository.delete(project);
        return "Project deleted successfully with Project ID: " + id;
    }

    @Override
    public List<ProjectDTO> getProjectsByOwner(Integer projectOwner)
            throws ProjectException {
        List<Project> projects =
            projectRepository.findByProjectOwner(projectOwner);

        if (projects.isEmpty()) {
            throw new ProjectException(
                "No projects found for owner ID: " + projectOwner
            );
        }

        List<ProjectDTO> projectDTOs = new ArrayList<>();
        for (Project project : projects) {
            projectDTOs.add(mapper.map(project, ProjectDTO.class));
        }
        return projectDTOs;
    }


}