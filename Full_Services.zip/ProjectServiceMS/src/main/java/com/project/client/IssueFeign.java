package com.project.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.project.model.IssueDTO;

@FeignClient(name = "IssueServiceMS", url = "http://localhost:7004/api/issues")
public interface IssueFeign {

	// Matches requirement: GET /api/projects/{projectId}/issues
	// Calling Issue Service at: http://localhost:8011/api/issues/project/{projectId}
	@GetMapping("/project/{projectId}")
	public List<IssueDTO> getIssuesByProjectId(@PathVariable Integer projectId) throws Exception;
}