package com.user.utility;

public enum Status {
	TO_DO, DEVELOPMENT, TESTING, DONE
}
