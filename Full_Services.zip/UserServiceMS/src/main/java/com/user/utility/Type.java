package com.user.utility;

public enum Type {
	BUG, TASK
}
