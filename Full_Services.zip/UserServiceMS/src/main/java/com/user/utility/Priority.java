package com.user.utility;

public enum Priority {
	HIGH, MEDIUM, LOW
}
