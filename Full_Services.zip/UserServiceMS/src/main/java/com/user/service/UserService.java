package com.user.service;

import java.util.List;

import com.user.exception.UserException;
import com.user.model.IssueDTO;
import com.user.model.UserDTO;

import jakarta.validation.Valid;

public interface UserService {

	String registerUser(UserDTO userDTO) throws UserException;
	UserDTO loginUser(String name, String emailId, String password, String role) throws UserException;
	String updateUser(Integer userId, UserDTO userDTO) throws UserException;
	String deleteUser(Integer userId) throws UserException;
	List<UserDTO> getAllUsers() throws UserException;
	UserDTO getUserById(Integer userId) throws UserException;
	//List<IssueDTO> getIssuesByUserId(Integer userId)  throws Exception; 
	List<IssueDTO> getIssuesByUserId(Integer userId) throws Exception;
	List<IssueDTO> getIssuesByUsername(String username) throws Exception;
}
