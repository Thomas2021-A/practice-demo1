package com.issue.entity;
 
import java.time.LocalDate;
import com.issue.utility.Priority;
import com.issue.utility.Status;
import com.issue.utility.Type;
 
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.Data;
 
@Entity
@Data
@Table(name = "issue") 
public class Issue {
	@Id
	@TableGenerator(name = "issue_gen", initialValue = 7010, allocationSize = 1,
			table = "issue_seq", pkColumnName = "seq_name", valueColumnName = "seq_value")
	@GeneratedValue(generator = "issue_gen")
	private Integer id;
	private String summary;
	private String description;
	private Integer project;
	private Integer assignee;
	private Integer createdBy;
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	private String sprint;
	private Integer storyPoint;
	private String tags;
	@Enumerated(EnumType.STRING)
	private Priority priority;
	@Enumerated(EnumType.STRING)
	private Status status;
	@Enumerated(EnumType.STRING)
	private Type type;
}