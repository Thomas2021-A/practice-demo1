package com.issue.model;
 
import java.time.LocalDate;
import com.issue.utility.Priority;
import com.issue.utility.Status;
import com.issue.utility.Type;
 
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
 
@Data
public class IssueDTO {
	private Integer id;
 
	@NotBlank(message = "Summary cannot be blank")
	@Size(min = 5, max = 255, message = "Summary must be between 5 and 255 characters")
	private String summary;
	
	@Size(max = 255, message = "Description cannot exceed 255 characters")
	private String description;
	
	@NotNull(message = "Project ID cannot be null")
	private Integer project;
	
	@NotNull(message = "Assignee cannot be null")
	private Integer assignee;
	
	@NotNull(message = "Creator User ID (createdBy) cannot be null")
	private Integer createdBy;
	
	
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	
	@Pattern(regexp = "^[1-9][0-9]*$", message = "Sprint must be a positive number")
	private String sprint;
	
	
	@Min(value = 2, message = "Story point must be a prime number (minimum 2)")
	@Max(value = 100, message = "Story points cannot exceed 100")
	private Integer storyPoint;
	
	@Size(max = 100, message = "Tags cannot exceed 100 characters")
	private String tags;
	
	@NotNull(message = "Priority cannot be null")
	private Priority priority;
	
	@NotNull(message = "Status cannot be null")
	private Status status;
	
	@NotNull(message = "Issue type cannot be null")
	private Type type;
}