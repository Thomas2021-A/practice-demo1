package com.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.user.exception.UserException;
import com.user.model.IssueDTO;
import com.user.model.LoginDTO;
import com.user.model.UserDTO;
import com.user.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping({"/api/v1/users", "/api/users"})
public class UserController {

	@Autowired
	private UserService userService;

	/**
	 * GET /api/v1/users - Retrieve all registered users
	 */
	@GetMapping({"", "/", "/all"})
	public ResponseEntity<List<UserDTO>> getAllUsers() throws UserException {
		List<UserDTO> users = userService.getAllUsers();
		return new ResponseEntity<>(users, HttpStatus.OK);
	}

	/**
	 * POST /api/v1/users - Register a new user account
	 */
	@PostMapping({"", "/", "/register"})
	public ResponseEntity<String> registerUser(@Valid @RequestBody UserDTO userDTO) throws UserException {
		String message = userService.registerUser(userDTO);
		return new ResponseEntity<>(message, HttpStatus.CREATED);
	}

	/**
	 * POST /api/v1/users/login - Authenticate user credentials
	 * Accepts either JSON request body (LoginDTO) or query/form parameters.
	 */
	@PostMapping("/login")
	public ResponseEntity<UserDTO> loginUser(
			@RequestBody(required = false) LoginDTO loginDTO,
			@RequestParam(required = false) String name,
			@RequestParam(required = false) String emailId,
			@RequestParam(required = false) String password,
			@RequestParam(required = false) String role) throws UserException {

		if (loginDTO != null && loginDTO.getEmailId() != null && !loginDTO.getEmailId().trim().isEmpty()) {
			UserDTO user = userService.login(loginDTO);
			return new ResponseEntity<>(user, HttpStatus.OK);
		}

		UserDTO user = userService.loginUser(name, emailId, password, role);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

	/**
	 * GET /api/v1/users/{userId} - Retrieve user details by ID
	 */
	@GetMapping("/{userId}")
	public ResponseEntity<UserDTO> getUserById(@PathVariable Integer userId) throws UserException {
		UserDTO userDTO = userService.getUserById(userId);
		return new ResponseEntity<>(userDTO, HttpStatus.OK);
	}

	/**
	 * GET /api/v1/users/{userId}/issues - Retrieve all issues assigned to user by ID
	 */
	@GetMapping("/{userId}/issues")
	public ResponseEntity<List<IssueDTO>> getIssuesByUserId(@PathVariable Integer userId) throws Exception {
		List<IssueDTO> issues = userService.getIssuesByUserId(userId);
		return new ResponseEntity<>(issues, HttpStatus.OK);
	}

	/**
	 * GET /api/v1/users/username/{username}/issues - Retrieve all issues assigned to user by username
	 */
	@GetMapping("/username/{username}/issues")
	public ResponseEntity<List<IssueDTO>> getIssuesByUsername(@PathVariable String username) throws Exception {
		List<IssueDTO> issues = userService.getIssuesByUsername(username);
		return new ResponseEntity<>(issues, HttpStatus.OK);
	}

	/**
	 * PUT /api/v1/users/{userId} - Update user details
	 */
	@PutMapping("/{userId}")
	public ResponseEntity<String> updateUser(@PathVariable Integer userId, @Valid @RequestBody UserDTO userDTO) throws UserException {
		String message = userService.updateUser(userId, userDTO);
		return new ResponseEntity<>(message, HttpStatus.OK);
	}

	/**
	 * DELETE /api/v1/users/{userId} - Delete user by ID
	 */
	@DeleteMapping("/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable Integer userId) throws UserException {
		String message = userService.deleteUser(userId);
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
}
