package com.user.model;

import com.user.utility.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserDTO {
	private Integer userId;
	
	@NotBlank(message = "Name cannot be blank")
	@Size(min = 2, max = 255, message = "Name must be between 2 and 255 characters")
	private String name;
	
	@NotBlank(message = "Email ID cannot be blank")
	@Email(message = "Please provide a valid email address")
	private String emailId;

	@NotNull(message = "Role cannot be null")
	private Role role;

	@NotBlank(message = "Password cannot be blank")
	@Size(min = 6, message = "Password must be at least 6 characters long")
	private String password;

	@NotBlank(message = "Profile image URL cannot be blank")
	private String profileImage;
}
