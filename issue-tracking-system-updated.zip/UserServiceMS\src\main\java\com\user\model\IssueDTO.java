package com.user.model;

import java.time.LocalDate;

import com.user.utility.Priority;
import com.user.utility.Status;
import com.user.utility.Type;

import lombok.Data;

@Data
public class IssueDTO {
	private Integer id;
	private String summary;
	private String description;
	private Integer project;
	private Integer assignee;
	private Integer createdBy;
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	private String sprint;
	private Integer storyPoint;
	private String tags;
	private Priority priority;
	private Status status;
	private Type type;
}
