package com.issue;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import com.issue.utility.Priority;
import com.issue.utility.Status;
import com.issue.utility.Type;

public class EnumMappingTest {

	@Test
	void testStatusMapping() {
		// Integer code mappings from PDF Object Value Mapping (1 => To-Do, 2 => Development, 3 => Testing, 4 => Completed)
		assertEquals(Status.TO_DO, Status.fromValue(1));
		assertEquals(Status.TO_DO, Status.fromValue("1"));
		assertEquals(Status.TO_DO, Status.fromValue("To-Do"));
		assertEquals(Status.TO_DO, Status.fromValue("TO_DO"));

		assertEquals(Status.DEVELOPMENT, Status.fromValue(2));
		assertEquals(Status.DEVELOPMENT, Status.fromValue("2"));
		assertEquals(Status.DEVELOPMENT, Status.fromValue("Development"));

		assertEquals(Status.TESTING, Status.fromValue(3));
		assertEquals(Status.TESTING, Status.fromValue("3"));
		assertEquals(Status.TESTING, Status.fromValue("Testing"));

		assertEquals(Status.COMPLETED, Status.fromValue(4));
		assertEquals(Status.COMPLETED, Status.fromValue("4"));
		assertEquals(Status.COMPLETED, Status.fromValue("Completed"));
		assertEquals(Status.COMPLETED, Status.fromValue("DONE"));

		assertThrows(IllegalArgumentException.class, () -> Status.fromValue(5));
	}

	@Test
	void testPriorityMapping() {
		// 1 => LOW, 2 => MEDIUM, 3 => HIGH
		assertEquals(Priority.LOW, Priority.fromValue(1));
		assertEquals(Priority.LOW, Priority.fromValue("1"));
		assertEquals(Priority.LOW, Priority.fromValue("LOW"));

		assertEquals(Priority.MEDIUM, Priority.fromValue(2));
		assertEquals(Priority.MEDIUM, Priority.fromValue("2"));
		assertEquals(Priority.MEDIUM, Priority.fromValue("MEDIUM"));

		assertEquals(Priority.HIGH, Priority.fromValue(3));
		assertEquals(Priority.HIGH, Priority.fromValue("3"));
		assertEquals(Priority.HIGH, Priority.fromValue("HIGH"));

		assertThrows(IllegalArgumentException.class, () -> Priority.fromValue(4));
	}

	@Test
	void testTypeMapping() {
		// 1 => BUG, 2 => TASK, 3 => STORY
		assertEquals(Type.BUG, Type.fromValue(1));
		assertEquals(Type.BUG, Type.fromValue("1"));
		assertEquals(Type.BUG, Type.fromValue("BUG"));

		assertEquals(Type.TASK, Type.fromValue(2));
		assertEquals(Type.TASK, Type.fromValue("2"));
		assertEquals(Type.TASK, Type.fromValue("TASK"));

		assertEquals(Type.STORY, Type.fromValue(3));
		assertEquals(Type.STORY, Type.fromValue("3"));
		assertEquals(Type.STORY, Type.fromValue("STORY"));
		assertEquals(Type.STORY, Type.fromValue("FEATURE"));

		assertThrows(IllegalArgumentException.class, () -> Type.fromValue(4));
	}
}
