package com.project.service;

import java.util.List;

import com.project.exception.ProjectException;
import com.project.model.IssueDTO;
import com.project.model.ProjectDTO;
import com.project.model.ProjectInsightsDTO;

public interface ProjectService {
	String createProject(ProjectDTO projectDTO) throws ProjectException;
	ProjectDTO getProjectById(Integer id) throws ProjectException;
	List<ProjectDTO> getAllProjects() throws ProjectException;
	String updateProject(Integer id, ProjectDTO projectDTO) throws ProjectException;
	String deleteProject(Integer id) throws ProjectException;
	List<ProjectDTO> getProjectsByOwner(Integer projectOwner) throws ProjectException;
	List<IssueDTO> getIssuesByProjectId(Integer projectId) throws Exception;
	List<IssueDTO> getIssuesByProjectName(String projectName) throws Exception;
	ProjectInsightsDTO getProjectInsights(Integer projectId) throws Exception;
}
