package com.project.utility;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Status {
	TO_DO(1, "To-Do"),
	DEVELOPMENT(2, "Development"),
	TESTING(3, "Testing"),
	COMPLETED(4, "Completed"),
	DONE(4, "Done");

	private final int code;
	private final String label;

	Status(int code, String label) {
		this.code = code;
		this.label = label;
	}

	public int getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	@JsonCreator
	public static Status fromValue(Object value) {
		if (value == null) {
			return null;
		}
		String str = value.toString().trim();
		if (str.isEmpty()) {
			return null;
		}
		if (str.equals("1") || str.equalsIgnoreCase("TO_DO") || str.equalsIgnoreCase("TO-DO") || str.equalsIgnoreCase("To-Do") || str.equalsIgnoreCase("TODO")) {
			return TO_DO;
		}
		if (str.equals("2") || str.equalsIgnoreCase("DEVELOPMENT") || str.equalsIgnoreCase("Development") || str.equalsIgnoreCase("IN_PROGRESS")) {
			return DEVELOPMENT;
		}
		if (str.equals("3") || str.equalsIgnoreCase("TESTING") || str.equalsIgnoreCase("Testing")) {
			return TESTING;
		}
		if (str.equals("4") || str.equalsIgnoreCase("COMPLETED") || str.equalsIgnoreCase("Completed") || str.equalsIgnoreCase("DONE") || str.equalsIgnoreCase("Done")) {
			return COMPLETED;
		}
		for (Status s : Status.values()) {
			if (s.name().equalsIgnoreCase(str)) {
				return s;
			}
		}
		throw new IllegalArgumentException("Invalid status: " + value + ". Allowed values: 1 (To-Do), 2 (Development), 3 (Testing), 4 (Completed)");
	}
}
