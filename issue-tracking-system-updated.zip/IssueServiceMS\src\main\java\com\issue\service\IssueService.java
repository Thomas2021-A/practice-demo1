package com.issue.service;

import java.util.List;

import com.issue.exception.IssueException;
import com.issue.model.IssueDTO;

public interface IssueService {

	List<IssueDTO> getIssuesByAssigneeId(Integer assigneeId) throws IssueException;
	IssueDTO getIssueById(Integer id) throws IssueException;
	String createIssue(IssueDTO issueDTO) throws IssueException;
	List<IssueDTO> getAllIssues() throws IssueException;
	String updateIssue(Integer id, IssueDTO issueDTO) throws IssueException;
	List<IssueDTO> getIssuesByProjectId(Integer projectId) throws IssueException;
	List<IssueDTO> getIssuesByOwnerId(Integer ownerId) throws IssueException;
}
