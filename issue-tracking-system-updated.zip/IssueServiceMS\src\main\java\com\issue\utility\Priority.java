package com.issue.utility;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Priority {
	LOW(1, "LOW"),
	MEDIUM(2, "MEDIUM"),
	HIGH(3, "HIGH");

	private final int code;
	private final String label;

	Priority(int code, String label) {
		this.code = code;
		this.label = label;
	}

	public int getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	@JsonCreator
	public static Priority fromValue(Object value) {
		if (value == null) {
			return null;
		}
		String str = value.toString().trim();
		if (str.isEmpty()) {
			return null;
		}
		if (str.equals("1") || str.equalsIgnoreCase("LOW")) {
			return LOW;
		}
		if (str.equals("2") || str.equalsIgnoreCase("MEDIUM")) {
			return MEDIUM;
		}
		if (str.equals("3") || str.equalsIgnoreCase("HIGH")) {
			return HIGH;
		}
		for (Priority p : Priority.values()) {
			if (p.name().equalsIgnoreCase(str)) {
				return p;
			}
		}
		throw new IllegalArgumentException("Invalid priority: " + value + ". Allowed values: 1 (LOW), 2 (MEDIUM), 3 (HIGH)");
	}
}
