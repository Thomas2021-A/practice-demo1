package com.user;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Requires live MySQL database connection on localhost:3306")
class UserServiceMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
