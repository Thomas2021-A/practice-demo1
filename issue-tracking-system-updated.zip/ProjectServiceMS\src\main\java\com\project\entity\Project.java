package com.project.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.Data;

@Entity
@Data
@Table(name = "project")
public class Project {

	 @Id
	    @TableGenerator(
	        name = "project_gen",
	        initialValue = 3010,
	        allocationSize = 1,
	        table = "project_seq",
	        pkColumnName = "gen_name",
	        valueColumnName = "gen_value"
	    )
	    @GeneratedValue(generator = "project_gen")
	    private Integer id;

	    @Column(name = "project_owner")
	    private Integer projectOwner;

	    @Column(name = "start_date")
	    private LocalDate startDate;

	    @Column(name = "end_date")
	    private LocalDate endDate;

	    @Column(name = "project_name", length = 255)
	    private String projectName;
	}


