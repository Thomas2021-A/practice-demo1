package com.project.model;

import java.util.Map;
import lombok.Data;

@Data
public class ProjectInsightsDTO {
	private Integer projectId;
	private String projectName;
	private Integer totalIssues;
	private Integer toDoCount;
	private Integer developmentCount;
	private Integer testingCount;
	private Integer completedCount;
	private Integer totalStoryPoints;
	private Integer completedStoryPoints;
	private Map<String, Long> statusBreakdown;
	private Map<String, Long> priorityBreakdown;
	private Map<String, Long> typeBreakdown;
}
