package com.project.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.client.IssueFeign;
import com.project.entity.Project;
import com.project.exception.ProjectException;
import com.project.model.IssueDTO;
import com.project.model.ProjectDTO;
import com.project.model.ProjectInsightsDTO;
import com.project.repository.ProjectRepository;
import com.project.utility.Status;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private IssueFeign issueFeign;

	@Override
	public List<IssueDTO> getIssuesByProjectId(Integer projectId) throws Exception {
		if (projectId == null || projectId <= 0) {
			throw new ProjectException("Invalid project ID: " + projectId);
		}
		// Verify project exists
		projectRepository.findById(projectId)
				.orElseThrow(() -> new ProjectException("Project not found with ID: " + projectId));

		try {
			List<IssueDTO> issues = issueFeign.getIssuesByProjectId(projectId);
			return (issues != null) ? issues : new ArrayList<>();
		} catch (Exception exception) {
			return new ArrayList<>();
		}
	}

	@Override
	public List<IssueDTO> getIssuesByProjectName(String projectName) throws Exception {
		if (projectName == null || projectName.trim().isEmpty()) {
			throw new ProjectException("Project name cannot be empty");
		}

		Project project = projectRepository.findByProjectName(projectName.trim())
				.orElseThrow(() -> new ProjectException("Project not found with name: " + projectName));

		try {
			List<IssueDTO> issues = issueFeign.getIssuesByProjectId(project.getId());
			return (issues != null) ? issues : new ArrayList<>();
		} catch (Exception exception) {
			return new ArrayList<>();
		}
	}

	@Override
	public String createProject(ProjectDTO projectDTO) throws ProjectException {
		if (projectDTO == null) {
			throw new ProjectException("Project details cannot be null");
		}

		if (projectDTO.getStartDate() != null && projectDTO.getEndDate() != null) {
			if (projectDTO.getEndDate().isBefore(projectDTO.getStartDate())) {
				throw new ProjectException("End date cannot be earlier than start date");
			}
		}

		// Check duplicate project name
		Optional<Project> existing = projectRepository.findByProjectName(projectDTO.getProjectName().trim());
		if (existing.isPresent()) {
			throw new ProjectException("Project name already exists: " + projectDTO.getProjectName());
		}

		Project project = new Project();
		mapper.map(projectDTO, project);
		project.setId(null);
		project.setProjectName(projectDTO.getProjectName().trim());
		projectRepository.save(project);

		return "Project created successfully with Project ID: " + project.getId();
	}

	@Override
	public ProjectDTO getProjectById(Integer id) throws ProjectException {
		if (id == null || id <= 0) {
			throw new ProjectException("Invalid project ID: " + id);
		}
		Project project = projectRepository.findById(id)
				.orElseThrow(() -> new ProjectException("Project not found with ID: " + id));

		return mapper.map(project, ProjectDTO.class);
	}

	@Override
	public List<ProjectDTO> getAllProjects() throws ProjectException {
		List<Project> projects = projectRepository.findAll();
		List<ProjectDTO> projectDTOs = new ArrayList<>();
		for (Project project : projects) {
			projectDTOs.add(mapper.map(project, ProjectDTO.class));
		}
		return projectDTOs;
	}

	@Override
	public String updateProject(Integer id, ProjectDTO projectDTO) throws ProjectException {
		if (id == null || id <= 0) {
			throw new ProjectException("Invalid project ID: " + id);
		}
		Project project = projectRepository.findById(id)
				.orElseThrow(() -> new ProjectException("Project not found with ID: " + id));

		if (projectDTO.getStartDate() != null && projectDTO.getEndDate() != null) {
			if (projectDTO.getEndDate().isBefore(projectDTO.getStartDate())) {
				throw new ProjectException("End date cannot be earlier than start date");
			}
		}

		if (projectDTO.getProjectName() != null && !projectDTO.getProjectName().trim().equalsIgnoreCase(project.getProjectName())) {
			Optional<Project> duplicate = projectRepository.findByProjectName(projectDTO.getProjectName().trim());
			if (duplicate.isPresent() && !duplicate.get().getId().equals(id)) {
				throw new ProjectException("Project name already exists: " + projectDTO.getProjectName());
			}
			project.setProjectName(projectDTO.getProjectName().trim());
		}

		if (projectDTO.getProjectOwner() != null) {
			project.setProjectOwner(projectDTO.getProjectOwner());
		}
		if (projectDTO.getStartDate() != null) {
			project.setStartDate(projectDTO.getStartDate());
		}
		if (projectDTO.getEndDate() != null) {
			project.setEndDate(projectDTO.getEndDate());
		}

		projectRepository.save(project);
		return "Project details updated successfully for Project ID: " + id;
	}

	@Override
	public String deleteProject(Integer id) throws ProjectException {
		if (id == null || id <= 0) {
			throw new ProjectException("Invalid project ID: " + id);
		}
		Project project = projectRepository.findById(id)
				.orElseThrow(() -> new ProjectException("Project not found with ID: " + id));

		projectRepository.delete(project);
		return "Project deleted successfully with Project ID: " + id;
	}

	@Override
	public List<ProjectDTO> getProjectsByOwner(Integer projectOwner) throws ProjectException {
		if (projectOwner == null || projectOwner <= 0) {
			throw new ProjectException("Invalid owner ID: " + projectOwner);
		}
		List<Project> projects = projectRepository.findByProjectOwner(projectOwner);
		List<ProjectDTO> projectDTOs = new ArrayList<>();
		for (Project project : projects) {
			projectDTOs.add(mapper.map(project, ProjectDTO.class));
		}
		return projectDTOs;
	}

	@Override
	public ProjectInsightsDTO getProjectInsights(Integer projectId) throws Exception {
		if (projectId == null || projectId <= 0) {
			throw new ProjectException("Invalid project ID: " + projectId);
		}
		Project project = projectRepository.findById(projectId)
				.orElseThrow(() -> new ProjectException("Project not found with ID: " + projectId));

		List<IssueDTO> issues;
		try {
			issues = issueFeign.getIssuesByProjectId(projectId);
			if (issues == null) {
				issues = new ArrayList<>();
			}
		} catch (Exception e) {
			issues = new ArrayList<>();
		}

		int totalIssues = issues.size();
		int toDoCount = 0;
		int developmentCount = 0;
		int testingCount = 0;
		int completedCount = 0;
		int totalStoryPoints = 0;
		int completedStoryPoints = 0;

		Map<String, Long> statusBreakdown = new HashMap<>();
		Map<String, Long> priorityBreakdown = new HashMap<>();
		Map<String, Long> typeBreakdown = new HashMap<>();

		for (IssueDTO issue : issues) {
			if (issue.getStatus() != null) {
				Status s = issue.getStatus();
				if (s == Status.TO_DO) {
					toDoCount++;
				} else if (s == Status.DEVELOPMENT) {
					developmentCount++;
				} else if (s == Status.TESTING) {
					testingCount++;
				} else if (s == Status.COMPLETED || s == Status.DONE) {
					completedCount++;
				}
				statusBreakdown.put(s.name(), statusBreakdown.getOrDefault(s.name(), 0L) + 1);
			}

			if (issue.getStoryPoint() != null && issue.getStoryPoint() > 0) {
				totalStoryPoints += issue.getStoryPoint();
				if (issue.getStatus() == Status.COMPLETED || issue.getStatus() == Status.DONE) {
					completedStoryPoints += issue.getStoryPoint();
				}
			}

			if (issue.getPriority() != null) {
				String pName = issue.getPriority().name();
				priorityBreakdown.put(pName, priorityBreakdown.getOrDefault(pName, 0L) + 1);
			}

			if (issue.getType() != null) {
				String tName = issue.getType().name();
				typeBreakdown.put(tName, typeBreakdown.getOrDefault(tName, 0L) + 1);
			}
		}

		ProjectInsightsDTO insights = new ProjectInsightsDTO();
		insights.setProjectId(project.getId());
		insights.setProjectName(project.getProjectName());
		insights.setTotalIssues(totalIssues);
		insights.setToDoCount(toDoCount);
		insights.setDevelopmentCount(developmentCount);
		insights.setTestingCount(testingCount);
		insights.setCompletedCount(completedCount);
		insights.setTotalStoryPoints(totalStoryPoints);
		insights.setCompletedStoryPoints(completedStoryPoints);
		insights.setStatusBreakdown(statusBreakdown);
		insights.setPriorityBreakdown(priorityBreakdown);
		insights.setTypeBreakdown(typeBreakdown);

		return insights;
	}
}
