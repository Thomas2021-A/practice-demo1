package com.issue.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.issue.entity.Issue;
import com.issue.exception.IssueException;
import com.issue.model.IssueDTO;
import com.issue.repository.IssueRepository;
import com.issue.utility.Status;

@Service
public class IssueServiceImpl implements IssueService {

	@Autowired
	private IssueRepository issueRepository;

	private boolean isPrime(Integer n) {
		if (n == null || n <= 1) {
			return false;
		}
		for (int i = 2; i * i <= n; i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}

	private IssueDTO convertToDTO(Issue issue) {
		IssueDTO dto = new IssueDTO();
		dto.setId(issue.getId());
		dto.setSummary(issue.getSummary());
		dto.setDescription(issue.getDescription());
		dto.setProject(issue.getProject());
		dto.setAssignee(issue.getAssignee());
		dto.setCreatedBy(issue.getCreatedBy());
		dto.setCreatedOn(issue.getCreatedOn());
		dto.setLastUpdated(issue.getLastUpdated());
		dto.setSprint(issue.getSprint());
		dto.setStoryPoint(issue.getStoryPoint());
		dto.setTags(issue.getTags());
		dto.setPriority(issue.getPriority());
		dto.setStatus(issue.getStatus());
		dto.setType(issue.getType());
		return dto;
	}

	@Override
	public List<IssueDTO> getIssuesByAssigneeId(Integer assigneeId) throws IssueException {
		if (assigneeId == null || assigneeId <= 0) {
			throw new IssueException("Invalid assignee ID: " + assigneeId);
		}
		List<Issue> issuesList = issueRepository.findByAssignee(assigneeId);
		List<IssueDTO> dtoList = new ArrayList<>();
		for (Issue issue : issuesList) {
			dtoList.add(convertToDTO(issue));
		}
		return dtoList;
	}

	@Override
	public IssueDTO getIssueById(Integer id) throws IssueException {
		if (id == null || id <= 0) {
			throw new IssueException("Invalid issue ID: " + id);
		}
		Optional<Issue> optional = issueRepository.findById(id);
		Issue issue = optional.orElseThrow(() -> new IssueException("Issue not found with ID: " + id));
		return convertToDTO(issue);
	}

	@Override
	public String createIssue(IssueDTO issueDTO) throws IssueException {
		if (issueDTO == null) {
			throw new IssueException("Issue details cannot be null");
		}

		// Validation: Story Point must be a prime number (PDF Page 7)
		if (issueDTO.getStoryPoint() != null && !isPrime(issueDTO.getStoryPoint())) {
			throw new IssueException("Story point must be a prime number (e.g., 2, 3, 5, 7, 11, 13, 17...)");
		}

		Issue issue = new Issue();
		issue.setSummary(issueDTO.getSummary().trim());
		issue.setDescription(issueDTO.getDescription() != null ? issueDTO.getDescription().trim() : null);
		issue.setProject(issueDTO.getProject());
		issue.setAssignee(issueDTO.getAssignee());
		issue.setCreatedBy(issueDTO.getCreatedBy());
		issue.setCreatedOn(LocalDate.now());
		issue.setLastUpdated(LocalDate.now());
		issue.setSprint(issueDTO.getSprint() != null ? issueDTO.getSprint().trim() : null);
		issue.setStoryPoint(issueDTO.getStoryPoint());
		issue.setTags(issueDTO.getTags() != null ? issueDTO.getTags().trim() : null);
		issue.setPriority(issueDTO.getPriority());
		issue.setStatus(issueDTO.getStatus() != null ? issueDTO.getStatus() : Status.TO_DO);
		issue.setType(issueDTO.getType());

		issueRepository.save(issue);
		return "Issue created successfully with Issue ID: " + issue.getId();
	}

	@Override
	public List<IssueDTO> getAllIssues() throws IssueException {
		List<Issue> issuesList = issueRepository.findAll();
		List<IssueDTO> dtoList = new ArrayList<>();
		for (Issue issue : issuesList) {
			dtoList.add(convertToDTO(issue));
		}
		return dtoList;
	}

	@Override
	public String updateIssue(Integer id, IssueDTO issueDTO) throws IssueException {
		if (id == null || id <= 0) {
			throw new IssueException("Invalid issue ID: " + id);
		}
		Optional<Issue> optional = issueRepository.findById(id);
		Issue issue = optional.orElseThrow(() -> new IssueException("Issue not found with ID: " + id));

		if (issueDTO.getSummary() != null && !issueDTO.getSummary().trim().isEmpty()) {
			issue.setSummary(issueDTO.getSummary().trim());
		}
		if (issueDTO.getDescription() != null) {
			issue.setDescription(issueDTO.getDescription().trim());
		}
		if (issueDTO.getProject() != null) {
			issue.setProject(issueDTO.getProject());
		}
		if (issueDTO.getAssignee() != null) {
			issue.setAssignee(issueDTO.getAssignee());
		}
		if (issueDTO.getCreatedBy() != null) {
			issue.setCreatedBy(issueDTO.getCreatedBy());
		}
		if (issueDTO.getSprint() != null && !issueDTO.getSprint().trim().isEmpty()) {
			issue.setSprint(issueDTO.getSprint().trim());
		}
		if (issueDTO.getStoryPoint() != null) {
			if (issueDTO.getStoryPoint() <= 0) {
				throw new IssueException("Story points must be a positive integer");
			}
			issue.setStoryPoint(issueDTO.getStoryPoint());
		}
		if (issueDTO.getTags() != null) {
			issue.setTags(issueDTO.getTags().trim());
		}
		if (issueDTO.getPriority() != null) {
			issue.setPriority(issueDTO.getPriority());
		}
		if (issueDTO.getStatus() != null) {
			issue.setStatus(issueDTO.getStatus());
		}
		if (issueDTO.getType() != null) {
			issue.setType(issueDTO.getType());
		}

		// Update last updated date
		issue.setLastUpdated(LocalDate.now());
		issueRepository.save(issue);

		return "Issue details updated successfully for ID: " + id;
	}

	@Override
	public List<IssueDTO> getIssuesByProjectId(Integer projectId) throws IssueException {
		if (projectId == null || projectId <= 0) {
			throw new IssueException("Invalid project ID: " + projectId);
		}
		List<Issue> issuesList = issueRepository.findByProject(projectId);
		List<IssueDTO> dtoList = new ArrayList<>();
		for (Issue issue : issuesList) {
			dtoList.add(convertToDTO(issue));
		}
		return dtoList;
	}

	@Override
	public List<IssueDTO> getIssuesByOwnerId(Integer ownerId) throws IssueException {
		if (ownerId == null || ownerId <= 0) {
			throw new IssueException("Invalid owner ID: " + ownerId);
		}
		List<Issue> issuesList = issueRepository.findByCreatedBy(ownerId);
		List<IssueDTO> dtoList = new ArrayList<>();
		for (Issue issue : issuesList) {
			dtoList.add(convertToDTO(issue));
		}
		return dtoList;
	}
}
