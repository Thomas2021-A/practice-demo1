package com.issue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.issue.exception.IssueException;
import com.issue.model.IssueDTO;
import com.issue.service.IssueService;

import jakarta.validation.Valid;

@RestController
@RequestMapping({"/api/v1/issues", "/api/issues"})
public class IssueController {

	@Autowired
	private IssueService issueService;

	/**
	 * GET /api/v1/issues/{id} - Retrieve issue by ID
	 */
	@GetMapping("/{id}")
	public ResponseEntity<IssueDTO> getIssueById(@PathVariable Integer id) throws IssueException {
		IssueDTO issueDTO = issueService.getIssueById(id);
		return new ResponseEntity<>(issueDTO, HttpStatus.OK);
	}

	/**
	 * PUT /api/v1/issues/{id} - Update issue by ID (supports full update and partial/status update)
	 */
	@PutMapping("/{id}")
	public ResponseEntity<String> updateIssue(@PathVariable Integer id, @RequestBody IssueDTO issueDTO) throws IssueException {
		String message = issueService.updateIssue(id, issueDTO);
		return new ResponseEntity<>(message, HttpStatus.OK);
	}

	/**
	 * GET /api/v1/issues - Retrieve all issues
	 */
	@GetMapping({"", "/"})
	public ResponseEntity<List<IssueDTO>> getAllIssues() throws IssueException {
		List<IssueDTO> issues = issueService.getAllIssues();
		return new ResponseEntity<>(issues, HttpStatus.OK);
	}

	/**
	 * POST /api/v1/issues - Create a new issue
	 */
	@PostMapping({"", "/"})
	public ResponseEntity<String> createIssue(@Valid @RequestBody IssueDTO issueDTO) throws IssueException {
		String message = issueService.createIssue(issueDTO);
		return new ResponseEntity<>(message, HttpStatus.CREATED);
	}

	/**
	 * GET /api/v1/issues/project/{projectId} - Retrieve all issues for a given project ID
	 */
	@GetMapping("/project/{projectId}")
	public ResponseEntity<List<IssueDTO>> getIssuesByProjectId(@PathVariable Integer projectId) throws IssueException {
		List<IssueDTO> issues = issueService.getIssuesByProjectId(projectId);
		return new ResponseEntity<>(issues, HttpStatus.OK);
	}

	/**
	 * GET /api/v1/issues/owner/{ownerId} - Retrieve all issues created by a specific owner/user
	 */
	@GetMapping("/owner/{ownerId}")
	public ResponseEntity<List<IssueDTO>> getIssuesByOwnerId(@PathVariable Integer ownerId) throws IssueException {
		List<IssueDTO> issues = issueService.getIssuesByOwnerId(ownerId);
		return new ResponseEntity<>(issues, HttpStatus.OK);
	}

	/**
	 * GET /api/v1/issues/assignee/{assigneeId} - Retrieve all issues assigned to a specific assignee
	 */
	@GetMapping("/assignee/{assigneeId}")
	public ResponseEntity<List<IssueDTO>> getIssuesByAssigneeId(@PathVariable Integer assigneeId) throws IssueException {
		List<IssueDTO> issues = issueService.getIssuesByAssigneeId(assigneeId);
		return new ResponseEntity<>(issues, HttpStatus.OK);
	}
}
