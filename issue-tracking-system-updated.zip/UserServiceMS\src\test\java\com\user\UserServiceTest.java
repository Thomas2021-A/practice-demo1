package com.user;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.user.client.IssueFeign;
import com.user.entity.User;
import com.user.exception.UserException;
import com.user.model.LoginDTO;
import com.user.model.UserDTO;
import com.user.repository.UserRepository;
import com.user.service.UserServiceImpl;
import com.user.utility.Role;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

	@Mock
	private UserRepository userRepository;

	@Mock
	private IssueFeign issueFeign;

	@Spy
	private ModelMapper mapper = new ModelMapper();

	@InjectMocks
	private UserServiceImpl userService;

	private User sampleUser;
	private UserDTO sampleUserDTO;

	@BeforeEach
	void setUp() {
		sampleUser = new User();
		sampleUser.setUserId(1001);
		sampleUser.setName("Tony Stark");
		sampleUser.setEmailId("tony@stark.com");
		sampleUser.setPassword("Stark@123");
		sampleUser.setRole(Role.PROJECT_OWNER);
		sampleUser.setProfileImage("https://stark.com/tony.jpg");

		sampleUserDTO = new UserDTO();
		sampleUserDTO.setUserId(1001);
		sampleUserDTO.setName("Tony Stark");
		sampleUserDTO.setEmailId("tony@stark.com");
		sampleUserDTO.setPassword("Stark@123");
		sampleUserDTO.setRole(Role.PROJECT_OWNER);
		sampleUserDTO.setProfileImage("https://stark.com/tony.jpg");
	}

	@Test
	void testRegisterUser_Success() throws UserException {
		when(userRepository.findByEmailId("tony@stark.com")).thenReturn(null);
		when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
			User u = invocation.getArgument(0);
			u.setUserId(1001);
			return u;
		});

		String result = userService.registerUser(sampleUserDTO);
		assertNotNull(result);
	}

	@Test
	void testRegisterUser_DuplicateEmail() {
		when(userRepository.findByEmailId("tony@stark.com")).thenReturn(sampleUser);
		assertThrows(UserException.class, () -> userService.registerUser(sampleUserDTO));
	}

	@Test
	void testLoginUser_Success() throws UserException {
		when(userRepository.findByEmailId("tony@stark.com")).thenReturn(sampleUser);
		UserDTO loggedIn = userService.loginUser("Tony Stark", "tony@stark.com", "Stark@123", "Project Owner");
		assertNotNull(loggedIn);
		assertEquals("tony@stark.com", loggedIn.getEmailId());
	}

	@Test
	void testLoginUser_InvalidPassword() {
		when(userRepository.findByEmailId("tony@stark.com")).thenReturn(sampleUser);
		assertThrows(UserException.class, () -> userService.loginUser("Tony Stark", "tony@stark.com", "WrongPassword", "Project Owner"));
	}

	@Test
	void testLoginUser_InvalidRole() {
		when(userRepository.findByEmailId("tony@stark.com")).thenReturn(sampleUser);
		assertThrows(UserException.class, () -> userService.loginUser("Tony Stark", "tony@stark.com", "Stark@123", "Assignee"));
	}

	@Test
	void testLoginUser_UserNotFound() {
		when(userRepository.findByEmailId("unknown@stark.com")).thenReturn(null);
		assertThrows(UserException.class, () -> userService.loginUser(null, "unknown@stark.com", "Stark@123", null));
	}

	@Test
	void testGetUserById_Success() throws UserException {
		when(userRepository.findById(1001)).thenReturn(Optional.of(sampleUser));
		UserDTO result = userService.getUserById(1001);
		assertNotNull(result);
		assertEquals(1001, result.getUserId());
	}

	@Test
	void testGetUserById_NotFound() {
		when(userRepository.findById(9999)).thenReturn(Optional.empty());
		assertThrows(UserException.class, () -> userService.getUserById(9999));
	}
}
