package com.project.model;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ProjectDTO {
	private Integer id;

	@NotBlank(message = "Project name cannot be blank")
	@Size(max = 150, message = "Project name cannot exceed 150 characters")
	@Pattern(regexp = "^[a-zA-Z0-9\\s\\-/.|]+$", message = "Project name cannot contain special characters except '-', '/', '|', '.'")
	private String projectName;

	@NotNull(message = "Project owner ID cannot be null")
	private Integer projectOwner;

	@NotNull(message = "Start date cannot be null")
	private LocalDate startDate;

	@NotNull(message = "End date cannot be null")
	private LocalDate endDate;
}
