package com.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.client.IssueFeign;
import com.user.entity.User;
import com.user.exception.UserException;
import com.user.model.IssueDTO;
import com.user.model.LoginDTO;
import com.user.model.UserDTO;
import com.user.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private IssueFeign issueFeign;

	@Override
	public List<IssueDTO> getIssuesByUserId(Integer userId) throws Exception {
		if (userId == null || userId <= 0) {
			throw new UserException("Invalid user ID: " + userId);
		}
		// Validate user existence first
		userRepository.findById(userId)
				.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		try {
			List<IssueDTO> issues = issueFeign.getIssuesByAssigneeId(userId);
			return (issues != null) ? issues : new ArrayList<>();
		} catch (Exception exception) {
			// If downstream returns no issues or not found, return empty list gracefully
			return new ArrayList<>();
		}
	}

	@Override
	public List<IssueDTO> getIssuesByUsername(String username) throws Exception {
		if (username == null || username.trim().isEmpty()) {
			throw new UserException("Username cannot be empty");
		}

		User user = userRepository.findByName(username.trim())
				.orElseThrow(() -> new UserException("User profile not found with name: " + username));

		try {
			List<IssueDTO> issues = issueFeign.getIssuesByAssigneeId(user.getUserId());
			return (issues != null) ? issues : new ArrayList<>();
		} catch (Exception exception) {
			return new ArrayList<>();
		}
	}

	@Override
	public String registerUser(UserDTO userDTO) throws UserException {
		if (userDTO == null) {
			throw new UserException("User details cannot be null");
		}
		// Duplicate email check
		User existing = userRepository.findByEmailId(userDTO.getEmailId().trim());
		if (existing != null) {
			throw new UserException("Email ID is already registered: " + userDTO.getEmailId());
		}

		User user = new User();
		mapper.map(userDTO, user);
		user.setUserId(null);
		user.setName(userDTO.getName().trim());
		user.setEmailId(userDTO.getEmailId().trim());
		user.setPassword(userDTO.getPassword());
		user.setRole(userDTO.getRole());
		user.setProfileImage(userDTO.getProfileImage() != null ? userDTO.getProfileImage().trim() : null);

		userRepository.save(user);
		return "User Registered successfully with User ID: " + user.getUserId();
	}

	@Override
	public UserDTO loginUser(String name, String emailId, String password, String role) throws UserException {
		if (emailId == null || emailId.trim().isEmpty()) {
			throw new UserException("Email address cannot be empty");
		}
		if (password == null || password.trim().isEmpty()) {
			throw new UserException("Password cannot be empty");
		}

		User user = userRepository.findByEmailId(emailId.trim());
		if (user == null) {
			throw new UserException("User not found with email: " + emailId);
		}
		if (!user.getPassword().equals(password)) {
			throw new UserException("Invalid password");
		}
		if (role != null && !role.trim().isEmpty()) {
			String normalizedInput = role.trim().toUpperCase().replace(" ", "_");
			if (!user.getRole().name().equals(normalizedInput)) {
				throw new UserException("Invalid role selected. Account is registered as: " + user.getRole().getLabel());
			}
		}

		return mapper.map(user, UserDTO.class);
	}

	@Override
	public UserDTO login(LoginDTO loginDTO) throws UserException {
		if (loginDTO == null) {
			throw new UserException("Login credentials cannot be null");
		}
		String roleStr = loginDTO.getRole() != null ? loginDTO.getRole().name() : null;
		return loginUser(loginDTO.getName(), loginDTO.getEmailId(), loginDTO.getPassword(), roleStr);
	}

	@Override
	public UserDTO getUserById(Integer userId) throws UserException {
		if (userId == null || userId <= 0) {
			throw new UserException("Invalid user ID: " + userId);
		}
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		return mapper.map(user, UserDTO.class);
	}

	@Override
	public List<UserDTO> getAllUsers() throws UserException {
		List<User> usersList = userRepository.findAll();
		List<UserDTO> userdtoList = new ArrayList<>();
		for (User user : usersList) {
			userdtoList.add(mapper.map(user, UserDTO.class));
		}
		return userdtoList;
	}

	@Override
	public String updateUser(Integer userId, UserDTO userDTO) throws UserException {
		if (userId == null || userId <= 0) {
			throw new UserException("Invalid user ID: " + userId);
		}
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		if (userDTO.getEmailId() != null && !userDTO.getEmailId().trim().equalsIgnoreCase(user.getEmailId())) {
			User existing = userRepository.findByEmailId(userDTO.getEmailId().trim());
			if (existing != null && !existing.getUserId().equals(userId)) {
				throw new UserException("Email ID is already registered: " + userDTO.getEmailId());
			}
			user.setEmailId(userDTO.getEmailId().trim());
		}

		if (userDTO.getName() != null) {
			user.setName(userDTO.getName().trim());
		}
		if (userDTO.getRole() != null) {
			user.setRole(userDTO.getRole());
		}
		if (userDTO.getPassword() != null) {
			user.setPassword(userDTO.getPassword());
		}
		if (userDTO.getProfileImage() != null) {
			user.setProfileImage(userDTO.getProfileImage().trim());
		}

		userRepository.save(user);
		return "User details updated successfully for User ID: " + userId;
	}

	@Override
	public String deleteUser(Integer userId) throws UserException {
		if (userId == null || userId <= 0) {
			throw new UserException("Invalid user ID: " + userId);
		}
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		userRepository.delete(user);
		return "User deleted successfully with User ID: " + userId;
	}
}
