package com.user.model;

import com.user.utility.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LoginDTO {
	@NotBlank(message = "Email ID cannot be blank")
	@Email(message = "Please provide a valid email address")
	private String emailId;

	@NotBlank(message = "Password cannot be blank")
	private String password;

	private Role role;
	private String name;
}
