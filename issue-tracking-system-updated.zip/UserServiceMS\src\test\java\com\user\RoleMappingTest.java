package com.user;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import com.user.utility.Role;

public class RoleMappingTest {

	@Test
	void testRoleMapping() {
		assertEquals(Role.PROJECT_OWNER, Role.fromValue("Project Owner"));
		assertEquals(Role.PROJECT_OWNER, Role.fromValue("PROJECT_OWNER"));
		assertEquals(Role.PROJECT_OWNER, Role.fromValue("PROJECT OWNER"));

		assertEquals(Role.ASSIGNEE, Role.fromValue("Assignee"));
		assertEquals(Role.ASSIGNEE, Role.fromValue("ASSIGNEE"));

		assertThrows(IllegalArgumentException.class, () -> Role.fromValue("Admin"));
	}
}
