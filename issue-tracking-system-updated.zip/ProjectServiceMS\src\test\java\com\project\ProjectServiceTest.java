package com.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.project.client.IssueFeign;
import com.project.entity.Project;
import com.project.exception.ProjectException;
import com.project.model.IssueDTO;
import com.project.model.ProjectDTO;
import com.project.model.ProjectInsightsDTO;
import com.project.repository.ProjectRepository;
import com.project.service.ProjectServiceImpl;
import com.project.utility.Priority;
import com.project.utility.Status;
import com.project.utility.Type;

@ExtendWith(MockitoExtension.class)
public class ProjectServiceTest {

	@Mock
	private ProjectRepository projectRepository;

	@Mock
	private IssueFeign issueFeign;

	@Spy
	private ModelMapper mapper = new ModelMapper();

	@InjectMocks
	private ProjectServiceImpl projectService;

	private Project sampleProject;
	private ProjectDTO sampleProjectDTO;

	@BeforeEach
	void setUp() {
		sampleProject = new Project();
		sampleProject.setId(3010);
		sampleProject.setProjectName("FedEx Courier Service");
		sampleProject.setProjectOwner(1001);
		sampleProject.setStartDate(LocalDate.of(2026, 5, 30));
		sampleProject.setEndDate(LocalDate.of(2026, 6, 17));

		sampleProjectDTO = new ProjectDTO();
		sampleProjectDTO.setId(3010);
		sampleProjectDTO.setProjectName("FedEx Courier Service");
		sampleProjectDTO.setProjectOwner(1001);
		sampleProjectDTO.setStartDate(LocalDate.of(2026, 5, 30));
		sampleProjectDTO.setEndDate(LocalDate.of(2026, 6, 17));
	}

	@Test
	void testCreateProject_Success() throws ProjectException {
		when(projectRepository.findByProjectName("FedEx Courier Service")).thenReturn(Optional.empty());
		when(projectRepository.save(any(Project.class))).thenAnswer(inv -> {
			Project p = inv.getArgument(0);
			p.setId(3010);
			return p;
		});

		String result = projectService.createProject(sampleProjectDTO);
		assertNotNull(result);
	}

	@Test
	void testCreateProject_EndDateBeforeStartDate() {
		sampleProjectDTO.setStartDate(LocalDate.of(2026, 6, 17));
		sampleProjectDTO.setEndDate(LocalDate.of(2026, 5, 30));

		assertThrows(ProjectException.class, () -> projectService.createProject(sampleProjectDTO));
	}

	@Test
	void testCreateProject_DuplicateProjectName() {
		when(projectRepository.findByProjectName("FedEx Courier Service")).thenReturn(Optional.of(sampleProject));
		assertThrows(ProjectException.class, () -> projectService.createProject(sampleProjectDTO));
	}

	@Test
	void testGetProjectById_Success() throws ProjectException {
		when(projectRepository.findById(3010)).thenReturn(Optional.of(sampleProject));
		ProjectDTO result = projectService.getProjectById(3010);
		assertNotNull(result);
		assertEquals(3010, result.getId());
	}

	@Test
	void testGetProjectById_NotFound() {
		when(projectRepository.findById(9999)).thenReturn(Optional.empty());
		assertThrows(ProjectException.class, () -> projectService.getProjectById(9999));
	}

	@Test
	void testGetProjectInsights_CalculatesCorrectMetrics() throws Exception {
		when(projectRepository.findById(3010)).thenReturn(Optional.of(sampleProject));

		IssueDTO issue1 = new IssueDTO();
		issue1.setId(1);
		issue1.setStatus(Status.TO_DO);
		issue1.setPriority(Priority.HIGH);
		issue1.setType(Type.BUG);
		issue1.setStoryPoint(3);

		IssueDTO issue2 = new IssueDTO();
		issue2.setId(2);
		issue2.setStatus(Status.DEVELOPMENT);
		issue2.setPriority(Priority.MEDIUM);
		issue2.setType(Type.TASK);
		issue2.setStoryPoint(5);

		IssueDTO issue3 = new IssueDTO();
		issue3.setId(3);
		issue3.setStatus(Status.COMPLETED);
		issue3.setPriority(Priority.LOW);
		issue3.setType(Type.STORY);
		issue3.setStoryPoint(7);

		when(issueFeign.getIssuesByProjectId(3010)).thenReturn(Arrays.asList(issue1, issue2, issue3));

		ProjectInsightsDTO insights = projectService.getProjectInsights(3010);
		assertNotNull(insights);
		assertEquals(3, insights.getTotalIssues());
		assertEquals(1, insights.getToDoCount());
		assertEquals(1, insights.getDevelopmentCount());
		assertEquals(0, insights.getTestingCount());
		assertEquals(1, insights.getCompletedCount());
		assertEquals(15, insights.getTotalStoryPoints()); // 3 + 5 + 7 = 15
		assertEquals(7, insights.getCompletedStoryPoints()); // issue3 = 7
	}
}
