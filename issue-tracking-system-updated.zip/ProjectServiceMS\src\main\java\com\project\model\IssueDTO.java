package com.project.model;

import java.time.LocalDate;

import com.project.utility.Priority;
import com.project.utility.Status;
import com.project.utility.Type;

import lombok.Data;

@Data
public class IssueDTO {
	private Integer id;
	private String summary;
	private String description;
	private Integer project;
	private Integer assignee;
	private Integer createdBy;
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	private String sprint;
	private Integer storyPoint;
	private String tags;
	private Priority priority;
	private Status status;
	private Type type;
}
