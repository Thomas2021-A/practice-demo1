package com.user.utility;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Role {
	PROJECT_OWNER("Project Owner"),
	ASSIGNEE("Assignee");

	private final String label;

	Role(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	@JsonCreator
	public static Role fromValue(Object value) {
		if (value == null) {
			return null;
		}
		String str = value.toString().trim();
		if (str.isEmpty()) {
			return null;
		}
		if (str.equalsIgnoreCase("PROJECT_OWNER") || str.equalsIgnoreCase("Project Owner") || str.equalsIgnoreCase("PROJECT OWNER")) {
			return PROJECT_OWNER;
		}
		if (str.equalsIgnoreCase("ASSIGNEE") || str.equalsIgnoreCase("Assignee")) {
			return ASSIGNEE;
		}
		for (Role r : Role.values()) {
			if (r.name().equalsIgnoreCase(str)) {
				return r;
			}
		}
		throw new IllegalArgumentException("Invalid role: " + value + ". Allowed values: Project Owner, Assignee");
	}
}
