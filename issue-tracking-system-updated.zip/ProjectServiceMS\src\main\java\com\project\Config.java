package com.project;

import org.modelmapper.ModelMapper;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class Config {
	
	@Bean
	public OpenAPI openAPI() {
		return new OpenAPI()
				.info(new Info()
				.title("Project Management API")
				.version("1.0")
				.description("API for managing users in the application"));
	}
	
	
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
}
