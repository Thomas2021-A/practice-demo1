package com.project.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.entity.Project;

public interface ProjectRepository extends JpaRepository<Project, Integer> {

	List<Project> findByProjectOwner(Integer projectOwner);

	Optional<Project> findByProjectName(String projectName);
	
}
