package com.issue.utility;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Type {
	BUG(1, "Bug"),
	TASK(2, "Task"),
	STORY(3, "Story"),
	FEATURE(3, "Feature");

	private final int code;
	private final String label;

	Type(int code, String label) {
		this.code = code;
		this.label = label;
	}

	public int getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	@JsonCreator
	public static Type fromValue(Object value) {
		if (value == null) {
			return null;
		}
		String str = value.toString().trim();
		if (str.isEmpty()) {
			return null;
		}
		if (str.equals("1") || str.equalsIgnoreCase("BUG") || str.equalsIgnoreCase("Bug")) {
			return BUG;
		}
		if (str.equals("2") || str.equalsIgnoreCase("TASK") || str.equalsIgnoreCase("Task")) {
			return TASK;
		}
		if (str.equals("3") || str.equalsIgnoreCase("STORY") || str.equalsIgnoreCase("Story") || str.equalsIgnoreCase("FEATURE") || str.equalsIgnoreCase("Feature")) {
			return STORY;
		}
		for (Type t : Type.values()) {
			if (t.name().equalsIgnoreCase(str)) {
				return t;
			}
		}
		throw new IllegalArgumentException("Invalid type: " + value + ". Allowed values: 1 (BUG), 2 (TASK), 3 (STORY)");
	}
}
