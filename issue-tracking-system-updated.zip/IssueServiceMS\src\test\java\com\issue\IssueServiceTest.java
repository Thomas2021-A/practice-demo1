package com.issue;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.issue.entity.Issue;
import com.issue.exception.IssueException;
import com.issue.model.IssueDTO;
import com.issue.repository.IssueRepository;
import com.issue.service.IssueServiceImpl;
import com.issue.utility.Priority;
import com.issue.utility.Status;
import com.issue.utility.Type;

@ExtendWith(MockitoExtension.class)
public class IssueServiceTest {

	@Mock
	private IssueRepository issueRepository;

	@InjectMocks
	private IssueServiceImpl issueService;

	private Issue sampleIssue;
	private IssueDTO sampleIssueDTO;

	@BeforeEach
	void setUp() {
		sampleIssue = new Issue();
		sampleIssue.setId(7010);
		sampleIssue.setSummary("Fix login authentication bug");
		sampleIssue.setDescription("Users report issue with login timeout");
		sampleIssue.setProject(3010);
		sampleIssue.setAssignee(1002);
		sampleIssue.setCreatedBy(1001);
		sampleIssue.setCreatedOn(LocalDate.now());
		sampleIssue.setLastUpdated(LocalDate.now());
		sampleIssue.setSprint("1");
		sampleIssue.setStoryPoint(5); // 5 is prime
		sampleIssue.setTags("#auth #bug");
		sampleIssue.setPriority(Priority.HIGH);
		sampleIssue.setStatus(Status.TO_DO);
		sampleIssue.setType(Type.BUG);

		sampleIssueDTO = new IssueDTO();
		sampleIssueDTO.setId(7010);
		sampleIssueDTO.setSummary("Fix login authentication bug");
		sampleIssueDTO.setDescription("Users report issue with login timeout");
		sampleIssueDTO.setProject(3010);
		sampleIssueDTO.setAssignee(1002);
		sampleIssueDTO.setCreatedBy(1001);
		sampleIssueDTO.setSprint("1");
		sampleIssueDTO.setStoryPoint(5); // 5 is prime
		sampleIssueDTO.setTags("#auth #bug");
		sampleIssueDTO.setPriority(Priority.HIGH);
		sampleIssueDTO.setStatus(Status.TO_DO);
		sampleIssueDTO.setType(Type.BUG);
	}

	@Test
	void testCreateIssue_Success_WithPrimeStoryPoint() throws IssueException {
		when(issueRepository.save(any(Issue.class))).thenAnswer(inv -> {
			Issue i = inv.getArgument(0);
			i.setId(7010);
			return i;
		});

		String result = issueService.createIssue(sampleIssueDTO);
		assertNotNull(result);
		assertTrue(result.contains("7010"));
	}

	@Test
	void testCreateIssue_NonPrimeStoryPoint_ThrowsException() {
		sampleIssueDTO.setStoryPoint(4); // 4 is not prime
		assertThrows(IssueException.class, () -> issueService.createIssue(sampleIssueDTO));

		sampleIssueDTO.setStoryPoint(9); // 9 is not prime
		assertThrows(IssueException.class, () -> issueService.createIssue(sampleIssueDTO));

		sampleIssueDTO.setStoryPoint(1); // 1 is not prime
		assertThrows(IssueException.class, () -> issueService.createIssue(sampleIssueDTO));
	}

	@Test
	void testCreateIssue_DefaultStatus_SetToToDo() throws IssueException {
		sampleIssueDTO.setStatus(null);
		when(issueRepository.save(any(Issue.class))).thenAnswer(inv -> {
			Issue i = inv.getArgument(0);
			assertEquals(Status.TO_DO, i.getStatus());
			i.setId(7011);
			return i;
		});

		String result = issueService.createIssue(sampleIssueDTO);
		assertNotNull(result);
	}

	@Test
	void testGetIssueById_Success() throws IssueException {
		when(issueRepository.findById(7010)).thenReturn(Optional.of(sampleIssue));
		IssueDTO result = issueService.getIssueById(7010);
		assertNotNull(result);
		assertEquals(7010, result.getId());
	}

	@Test
	void testGetIssueById_NotFound() {
		when(issueRepository.findById(9999)).thenReturn(Optional.empty());
		assertThrows(IssueException.class, () -> issueService.getIssueById(9999));
	}

	@Test
	void testUpdateIssue_PartialUpdate_PreservesExistingFields() throws IssueException {
		when(issueRepository.findById(7010)).thenReturn(Optional.of(sampleIssue));
		when(issueRepository.save(any(Issue.class))).thenAnswer(inv -> inv.getArgument(0));

		// Partial update from Assignee dashboard changing only status
		IssueDTO updateDTO = new IssueDTO();
		updateDTO.setStatus(Status.DEVELOPMENT);

		String result = issueService.updateIssue(7010, updateDTO);
		assertNotNull(result);
		assertEquals(Status.DEVELOPMENT, sampleIssue.getStatus());
		// Existing fields preserved
		assertEquals("Fix login authentication bug", sampleIssue.getSummary());
		assertEquals(5, sampleIssue.getStoryPoint());
	}

	@Test
	void testGetIssuesByProjectId_ReturnsEmptyListWhenEmpty() throws IssueException {
		when(issueRepository.findByProject(3010)).thenReturn(Collections.emptyList());
		List<IssueDTO> issues = issueService.getIssuesByProjectId(3010);
		assertNotNull(issues);
		assertTrue(issues.isEmpty());
	}
}
