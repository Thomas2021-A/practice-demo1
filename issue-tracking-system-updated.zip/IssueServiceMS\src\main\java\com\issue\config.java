package com.issue;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
 
@Configuration
public class config {
	@Bean
	public OpenAPI orderOpenAPI() {
		OpenAPI openAPI = new OpenAPI();
		return openAPI.info(new Info()
				.title("Issue Management API")
				.version("1.0")
				.description("API for managing users in the application"));
	}
}