package com.issue.entity;

import java.time.LocalDate;

import com.issue.utility.Priority;
import com.issue.utility.Status;
import com.issue.utility.Type;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.Data;

@Entity
@Data
@Table(name = "issue")
public class Issue {

	@Id
	@TableGenerator(name = "issue_gen", initialValue = 7010, allocationSize = 1,
			table = "issue_seq", pkColumnName = "seq_name", valueColumnName = "seq_value")
	@GeneratedValue(generator = "issue_gen")
	private Integer id;

	@Column(name = "summary", length = 150)
	private String summary;

	@Column(name = "description", length = 500)
	private String description;

	@Column(name = "project")
	private Integer project;

	@Column(name = "assignee")
	private Integer assignee;

	@Column(name = "created_by")
	private Integer createdBy;

	@Column(name = "created_on")
	private LocalDate createdOn;

	@Column(name = "last_updated")
	private LocalDate lastUpdated;

	@Column(name = "sprint")
	private String sprint;

	@Column(name = "story_point")
	private Integer storyPoint;

	@Column(name = "tags", length = 100)
	private String tags;

	@Enumerated(EnumType.STRING)
	@Column(name = "priority")
	private Priority priority;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private Status status;

	@Enumerated(EnumType.STRING)
	@Column(name = "type")
	private Type type;
}
