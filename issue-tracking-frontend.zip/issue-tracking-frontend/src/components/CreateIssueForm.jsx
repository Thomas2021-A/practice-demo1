import { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import Issue from "../model/Issue";
import { createIssue } from "../services/issueService";
import { getProjectsByOwner, getAllProjects } from "../services/projectService";
import { getAllUsers } from "../services/userService";

/**
 * Prime Number check helper
 * Special rule from PDF Page 7: Story Point only accepts Prime Numbers!
 */
function isPrime(val) {
    const num = parseInt(val, 10);
    if (isNaN(num) || num <= 1) return false;
    if (num <= 3) return true;
    if (num % 2 === 0 || num % 3 === 0) return false;
    for (let i = 5; i * i <= num; i += 6) {
        if (num % i === 0 || num % (i + 2) === 0) return false;
    }
    return true;
}

/**
 * CreateIssueForm Component
 * Requirements from PDF Page 7:
 * - Summary: String, Max Length = 150, Required, No special characters except {-, /, |, .}
 * - Type: Drop-down (BUG, TASK, STORY), Required
 * - Project: Drop-down from Project API, Required
 * - Description: Optional, Max Length = 500
 * - Priority: Drop-down (LOW, MEDIUM, HIGH), Required
 * - Assignee: Required, Drop-down from Users API
 * - Tags: Text-field, max-length = 100
 * - Story Point: Numeric field, only accepts Prime Numbers
 * - Sprint: Numbers (1, 2, 3...)
 * - Status: Drop-down (TO_DO, DEVELOPMENT, TESTING, COMPLETED/DONE)
 * - CREATE button: only enabled when valid, disables during API call, redirects on success
 * - RESET button: resets all fields to blank
 */
function CreateIssueForm() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();

    // Form fields
    const [summary, setSummary] = useState('');
    const [type, setType] = useState('');
    const [project, setProject] = useState('');
    const [priority, setPriority] = useState('');
    const [description, setDescription] = useState('');
    const [assignee, setAssignee] = useState('');
    const [tags, setTags] = useState('');
    const [sprint, setSprint] = useState('1');
    const [storyPoint, setStoryPoint] = useState('');
    const [status, setStatus] = useState('TO_DO');

    // Dropdown options loaded from APIs
    const [projectList, setProjectList] = useState([]);
    const [assigneeList, setAssigneeList] = useState([]);

    // Validation & server feedback
    const [touched, setTouched] = useState({});
    const [errors, setErrors] = useState({});
    const [serverError, setServerError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Fetch available projects and assignees
    useEffect(() => {
        const loadFormData = async () => {
            try {
                // Load projects
                let projects = [];
                if (user?.userId) {
                    projects = await getProjectsByOwner(user.userId);
                }
                if (!projects || projects.length === 0) {
                    projects = await getAllProjects();
                }
                setProjectList(Array.isArray(projects) ? projects : []);

                // Load users for assignee dropdown
                const users = await getAllUsers();
                if (Array.isArray(users)) {
                    // Filter assignees or all users
                    const assignees = users.filter(u => u.role === 'ASSIGNEE' || u.role === 'Assignee');
                    setAssigneeList(assignees.length > 0 ? assignees : users);
                }
            } catch (err) {
                console.warn('Error loading form dropdowns:', err);
            }
        };
        loadFormData();
    }, [user]);

    // Validation helpers
    const validateSummary = (val) => {
        if (!val || !val.trim()) return 'Summary is required.';
        if (val.length > 150) return 'Summary cannot exceed 150 characters.';
        const regex = /^[a-zA-Z0-9\s\-/.|]+$/;
        if (!regex.test(val)) {
            return 'No special characters allowed except { -, /, |, . }';
        }
        return '';
    };

    const validateType = (val) => (!val ? 'Type is required.' : '');
    const validateProject = (val) => (!val ? 'Project is required.' : '');
    const validatePriority = (val) => (!val ? 'Priority is required.' : '');
    const validateAssignee = (val) => (!val ? 'Assignee is required.' : '');

    const validateDescription = (val) => {
        if (val && val.length > 500) return 'Description cannot exceed 500 characters.';
        return '';
    };

    const validateTags = (val) => {
        if (val && val.length > 100) return 'Tags cannot exceed 100 characters.';
        return '';
    };

    const validateSprint = (val) => {
        if (!val) return 'Sprint is required.';
        if (!/^[1-9]\d*$/.test(String(val))) return 'Sprint must be a positive number (1, 2, 3...).';
        return '';
    };

    const validateStoryPoint = (val) => {
        if (!val) return 'Story Point is required.';
        if (!isPrime(val)) {
            return 'Story Point only accepts Prime Numbers (e.g., 2, 3, 5, 7, 11, 13...).';
        }
        return '';
    };

    const validateStatus = (val) => (!val ? 'Status is required.' : '');

    // Check overall form validity
    const isFormValid = () => {
        return (
            summary.trim() !== '' &&
            !validateSummary(summary) &&
            type !== '' &&
            project !== '' &&
            priority !== '' &&
            assignee !== '' &&
            !validateDescription(description) &&
            !validateTags(tags) &&
            sprint !== '' &&
            !validateSprint(sprint) &&
            storyPoint !== '' &&
            isPrime(storyPoint) &&
            status !== ''
        );
    };

    const handleBlur = (field) => {
        setTouched(prev => ({ ...prev, [field]: true }));
        validateField(field);
    };

    const validateField = (field) => {
        let err = '';
        switch (field) {
            case 'summary': err = validateSummary(summary); break;
            case 'type': err = validateType(type); break;
            case 'project': err = validateProject(project); break;
            case 'priority': err = validatePriority(priority); break;
            case 'assignee': err = validateAssignee(assignee); break;
            case 'description': err = validateDescription(description); break;
            case 'tags': err = validateTags(tags); break;
            case 'sprint': err = validateSprint(sprint); break;
            case 'storyPoint': err = validateStoryPoint(storyPoint); break;
            case 'status': err = validateStatus(status); break;
            default: break;
        }
        setErrors(prev => ({ ...prev, [field]: err }));
    };

    // Reset button handler
    const handleReset = () => {
        setSummary('');
        setType('');
        setProject('');
        setPriority('');
        setDescription('');
        setAssignee('');
        setTags('');
        setSprint('1');
        setStoryPoint('');
        setStatus('TO_DO');
        setTouched({});
        setErrors({});
        setServerError('');
    };

    // Submit handler
    const handleSubmit = async (e) => {
        e.preventDefault();
        setServerError('');

        const allErrors = {
            summary: validateSummary(summary),
            type: validateType(type),
            project: validateProject(project),
            priority: validatePriority(priority),
            assignee: validateAssignee(assignee),
            description: validateDescription(description),
            tags: validateTags(tags),
            sprint: validateSprint(sprint),
            storyPoint: validateStoryPoint(storyPoint),
            status: validateStatus(status)
        };

        const allTouched = Object.keys(allErrors).reduce((acc, k) => ({ ...acc, [k]: true }), {});
        setTouched(allTouched);
        setErrors(allErrors);

        if (Object.values(allErrors).some(err => err)) {
            return;
        }

        setIsSubmitting(true);
        try {
            // Mapping backend type (BUG, TASK; if STORY map to TASK or preserve)
            const backendType = type === 'STORY' ? 'TASK' : type;
            const backendStatus = status === 'COMPLETED' ? 'DONE' : status;

            const newIssue = new Issue(
                null,
                summary.trim(),
                description.trim(),
                Number(project),
                Number(assignee),
                Number(user?.userId || 1),
                '', // createdOn handled by backend / service
                '', // lastUpdated
                String(sprint),
                Number(storyPoint),
                tags.trim(),
                priority,
                backendStatus,
                backendType
            );

            await createIssue(newIssue);
            // On Success, redirect to project board
            navigate('/project-dashboard');
        } catch (err) {
            console.error('Failed to create issue:', err);
            setServerError(err.response?.data?.message || err.message || 'Server error creating issue.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="dashboard-layout">
            <Sidebar />

            <div className="main-wrapper">
                {/* Brand title Deloitte Engineering as in PDF Page 7 */}
                <TopBar showSearch={false} brandTitle="Deloitte Engineering" />

                <div className="content-body">
                    <h5 className="fw-bold text-dark mb-4" style={{ letterSpacing: '0.5px' }}>
                        Create Issue
                    </h5>

                    {serverError && (
                        <div className="alert alert-danger py-2" role="alert">
                            {serverError}
                        </div>
                    )}

                    <div className="form-card">
                        <form onSubmit={handleSubmit} noValidate>
                            <div className="row g-3">
                                {/* Summary */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Summary</label>
                                    <input
                                        type="text"
                                        maxLength={150}
                                        className={`form-control ${touched.summary && errors.summary ? 'is-invalid' : ''}`}
                                        placeholder="Enter summary"
                                        value={summary}
                                        onChange={(e) => setSummary(e.target.value)}
                                        onBlur={() => handleBlur('summary')}
                                    />
                                    {touched.summary && errors.summary && (
                                        <div className="invalid-feedback">{errors.summary}</div>
                                    )}
                                </div>

                                {/* Type */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Type</label>
                                    <select
                                        className={`form-select ${touched.type && errors.type ? 'is-invalid' : ''}`}
                                        value={type}
                                        onChange={(e) => setType(e.target.value)}
                                        onBlur={() => handleBlur('type')}
                                    >
                                        <option value="">Select type</option>
                                        <option value="BUG">BUG</option>
                                        <option value="TASK">TASK</option>
                                        <option value="STORY">STORY</option>
                                    </select>
                                    {touched.type && errors.type && (
                                        <div className="invalid-feedback">{errors.type}</div>
                                    )}
                                </div>

                                {/* Project */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Project</label>
                                    <select
                                        className={`form-select ${touched.project && errors.project ? 'is-invalid' : ''}`}
                                        value={project}
                                        onChange={(e) => setProject(e.target.value)}
                                        onBlur={() => handleBlur('project')}
                                    >
                                        <option value="">Select project</option>
                                        {projectList.map(p => (
                                            <option key={p.id} value={p.id}>
                                                {p.projectName}
                                            </option>
                                        ))}
                                    </select>
                                    {touched.project && errors.project && (
                                        <div className="invalid-feedback">{errors.project}</div>
                                    )}
                                </div>

                                {/* Priority */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Priority</label>
                                    <select
                                        className={`form-select ${touched.priority && errors.priority ? 'is-invalid' : ''}`}
                                        value={priority}
                                        onChange={(e) => setPriority(e.target.value)}
                                        onBlur={() => handleBlur('priority')}
                                    >
                                        <option value="">Select priority</option>
                                        <option value="LOW">LOW</option>
                                        <option value="MEDIUM">MEDIUM</option>
                                        <option value="HIGH">HIGH</option>
                                    </select>
                                    {touched.priority && errors.priority && (
                                        <div className="invalid-feedback">{errors.priority}</div>
                                    )}
                                </div>

                                {/* Description */}
                                <div className="col-12">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Description</label>
                                    <textarea
                                        rows={3}
                                        maxLength={500}
                                        className={`form-control ${touched.description && errors.description ? 'is-invalid' : ''}`}
                                        placeholder="Enter description"
                                        value={description}
                                        onChange={(e) => setDescription(e.target.value)}
                                        onBlur={() => handleBlur('description')}
                                    />
                                    {touched.description && errors.description && (
                                        <div className="invalid-feedback">{errors.description}</div>
                                    )}
                                </div>

                                {/* Assignee */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Assignee</label>
                                    <select
                                        className={`form-select ${touched.assignee && errors.assignee ? 'is-invalid' : ''}`}
                                        value={assignee}
                                        onChange={(e) => setAssignee(e.target.value)}
                                        onBlur={() => handleBlur('assignee')}
                                    >
                                        <option value="">Select assignee</option>
                                        {assigneeList.map(a => (
                                            <option key={a.userId} value={a.userId}>
                                                {a.name} ({a.emailId})
                                            </option>
                                        ))}
                                    </select>
                                    {touched.assignee && errors.assignee && (
                                        <div className="invalid-feedback">{errors.assignee}</div>
                                    )}
                                </div>

                                {/* Tags */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Tags</label>
                                    <input
                                        type="text"
                                        maxLength={100}
                                        className={`form-control ${touched.tags && errors.tags ? 'is-invalid' : ''}`}
                                        placeholder="Enter tags"
                                        value={tags}
                                        onChange={(e) => setTags(e.target.value)}
                                        onBlur={() => handleBlur('tags')}
                                    />
                                    {touched.tags && errors.tags && (
                                        <div className="invalid-feedback">{errors.tags}</div>
                                    )}
                                </div>

                                {/* Sprint */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Sprint</label>
                                    <input
                                        type="number"
                                        min={1}
                                        className={`form-control ${touched.sprint && errors.sprint ? 'is-invalid' : ''}`}
                                        placeholder="Enter sprint"
                                        value={sprint}
                                        onChange={(e) => setSprint(e.target.value)}
                                        onBlur={() => handleBlur('sprint')}
                                    />
                                    {touched.sprint && errors.sprint && (
                                        <div className="invalid-feedback">{errors.sprint}</div>
                                    )}
                                </div>

                                {/* Story Point (Only accepts Prime Numbers!) */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Story Point</label>
                                    <input
                                        type="number"
                                        min={2}
                                        className={`form-control ${touched.storyPoint && errors.storyPoint ? 'is-invalid' : ''}`}
                                        placeholder="Enter story points (Prime Numbers only, e.g. 2, 3, 5, 7, 11)"
                                        value={storyPoint}
                                        onChange={(e) => setStoryPoint(e.target.value)}
                                        onBlur={() => handleBlur('storyPoint')}
                                    />
                                    {touched.storyPoint && errors.storyPoint && (
                                        <div className="invalid-feedback">{errors.storyPoint}</div>
                                    )}
                                </div>

                                {/* Status */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">Status</label>
                                    <select
                                        className={`form-select ${touched.status && errors.status ? 'is-invalid' : ''}`}
                                        value={status}
                                        onChange={(e) => setStatus(e.target.value)}
                                        onBlur={() => handleBlur('status')}
                                    >
                                        <option value="TO_DO">To-Do</option>
                                        <option value="DEVELOPMENT">Development</option>
                                        <option value="TESTING">Testing</option>
                                        <option value="COMPLETED">Completed</option>
                                    </select>
                                    {touched.status && errors.status && (
                                        <div className="invalid-feedback">{errors.status}</div>
                                    )}
                                </div>
                            </div>

                            {/* Buttons Row */}
                            <div className="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                                <button
                                    type="submit"
                                    className="btn btn-warning px-4 fw-semibold text-uppercase"
                                    disabled={!isFormValid() || isSubmitting}
                                >
                                    {isSubmitting ? 'Creating...' : 'CREATE'}
                                </button>
                                <button
                                    type="button"
                                    className="btn btn-outline-secondary px-4 fw-semibold text-uppercase"
                                    onClick={handleReset}
                                    disabled={isSubmitting}
                                >
                                    RESET
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CreateIssueForm;
