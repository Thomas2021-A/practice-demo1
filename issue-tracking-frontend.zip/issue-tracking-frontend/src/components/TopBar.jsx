/**
 * TopBar Component
 * Renders the top navigation header with:
 * - Search bar on the left (with RegEx matching on summary / description)
 * - Amber title badge on the right ("Issue Tracking System" or "Deloitte Engineering")
 */
function TopBar({ searchQuery = '', onSearchChange = () => {}, showSearch = true, brandTitle = "Issue Tracking System" }) {
    return (
        <header className="top-navbar">
            {showSearch ? (
                <div className="top-search-group input-group">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Search issue by summary or description"
                        value={searchQuery}
                        onChange={(e) => onSearchChange(e.target.value)}
                    />
                    <button className="btn" type="button" title="Search">
                        🔍
                    </button>
                </div>
            ) : (
                <div></div>
            )}

            <div className="top-brand-badge">
                {brandTitle}
            </div>
        </header>
    );
}

export default TopBar;
