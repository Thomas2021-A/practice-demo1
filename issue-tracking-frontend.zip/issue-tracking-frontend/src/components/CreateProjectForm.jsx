import { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import Project from "../model/Project";
import { createProject } from "../services/projectService";
import { getAllUsers } from "../services/userService";

/**
 * CreateProjectForm Component
 * Requirements from PDF Page 6:
 * - Project Name: String, max-length (150), Required, No special characters except {-, /, |, .}
 * - Project Owner: Required Field, Drop-down fetched from API
 * - Project Start Date & End Date: Date Picker (End date should not be lesser than start date)
 * - Validations: Reactive form with expected validation & messages
 * - Buttons:
 *     - CREATE: Only enabled if form is valid, disabled during API request, on success redirects to dashboard, on failure shows error
 *     - RESET: All fields to blank
 */
function CreateProjectForm() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();

    // Form state
    const [projectName, setProjectName] = useState('');
    const [projectOwner, setProjectOwner] = useState(user?.userId ? String(user.userId) : '');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    // Available project owners list
    const [owners, setOwners] = useState([]);

    // Validation & submission states
    const [touched, setTouched] = useState({});
    const [errors, setErrors] = useState({});
    const [serverError, setServerError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Fetch owners from Users API
    useEffect(() => {
        const fetchOwners = async () => {
            try {
                const usersList = await getAllUsers();
                if (Array.isArray(usersList)) {
                    // Filter for project owners or provide all users
                    const poList = usersList.filter(u => u.role === 'PROJECT_OWNER' || u.role === 'Project Owner');
                    setOwners(poList.length > 0 ? poList : usersList);
                }
            } catch (err) {
                console.warn('Error fetching users for owner dropdown:', err);
            }
        };
        fetchOwners();
    }, []);

    // Set logged in user as default owner if not already selected
    useEffect(() => {
        if (user?.userId && !projectOwner) {
            setProjectOwner(String(user.userId));
        }
    }, [user, projectOwner]);

    // Validation rules
    const validateProjectName = (name) => {
        if (!name || !name.trim()) return 'Project name is required.';
        if (name.length > 150) return 'Project name cannot exceed 150 characters.';
        // Allowed characters: letters, numbers, spaces, and {-, /, |, .}
        const validPattern = /^[a-zA-Z0-9\s\-/.|]+$/;
        if (!validPattern.test(name)) {
            return 'No special characters allowed except { -, /, |, . }';
        }
        return '';
    };

    const validateOwner = (owner) => {
        if (!owner) return 'Project owner is required.';
        return '';
    };

    const validateDates = (start, end) => {
        const errs = {};
        if (!start) {
            errs.startDate = 'Project start date is required.';
        }
        if (!end) {
            errs.endDate = 'Project end date is required.';
        } else if (start && end) {
            if (new Date(end) < new Date(start)) {
                errs.endDate = 'End date should not be lesser than start date.';
            }
        }
        return errs;
    };

    // Live validation
    const handleBlur = (field) => {
        setTouched(prev => ({ ...prev, [field]: true }));
        updateErrors();
    };

    const updateErrors = () => {
        const nameErr = validateProjectName(projectName);
        const ownerErr = validateOwner(projectOwner);
        const dateErrs = validateDates(startDate, endDate);

        setErrors({
            projectName: nameErr,
            projectOwner: ownerErr,
            ...dateErrs
        });
    };

    // Determine overall form validity
    const isFormValid = () => {
        const nameErr = validateProjectName(projectName);
        const ownerErr = validateOwner(projectOwner);
        const dateErrs = validateDates(startDate, endDate);

        return (
            projectName.trim() !== '' &&
            projectOwner !== '' &&
            startDate !== '' &&
            endDate !== '' &&
            !nameErr &&
            !ownerErr &&
            !dateErrs.startDate &&
            !dateErrs.endDate
        );
    };

    // Reset button handler
    const handleReset = () => {
        setProjectName('');
        setProjectOwner('');
        setStartDate('');
        setEndDate('');
        setTouched({});
        setErrors({});
        setServerError('');
    };

    // Create submission handler
    const handleSubmit = async (e) => {
        e.preventDefault();
        setServerError('');

        const nameErr = validateProjectName(projectName);
        const ownerErr = validateOwner(projectOwner);
        const dateErrs = validateDates(startDate, endDate);

        const allErrors = {
            projectName: nameErr,
            projectOwner: ownerErr,
            ...dateErrs
        };

        setTouched({
            projectName: true,
            projectOwner: true,
            startDate: true,
            endDate: true
        });
        setErrors(allErrors);

        if (Object.values(allErrors).some(err => err)) {
            return;
        }

        setIsSubmitting(true);
        try {
            const newProj = new Project(
                null,
                projectName.trim(),
                Number(projectOwner),
                startDate,
                endDate
            );

            await createProject(newProj);
            // On Success, redirect to project dashboard
            navigate('/project-dashboard');
        } catch (err) {
            console.error('Failed to create project:', err);
            // On Failure, show error message from server
            setServerError(err.response?.data?.message || err.message || 'Server error creating project.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="dashboard-layout">
            <Sidebar />

            <div className="main-wrapper">
                <TopBar showSearch={false} brandTitle="Issue Tracking System" />

                <div className="content-body">
                    <h5 className="fw-bold text-dark mb-4" style={{ letterSpacing: '0.5px' }}>
                        Create Project
                    </h5>

                    {serverError && (
                        <div className="alert alert-danger py-2" role="alert">
                            {serverError}
                        </div>
                    )}

                    <div className="form-card">
                        <form onSubmit={handleSubmit} noValidate>
                            <div className="row g-4">
                                {/* Project Name */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">
                                        Project Name
                                    </label>
                                    <input
                                        type="text"
                                        maxLength={150}
                                        className={`form-control ${touched.projectName && errors.projectName ? 'is-invalid' : ''}`}
                                        placeholder="Enter project name"
                                        value={projectName}
                                        onChange={(e) => {
                                            setProjectName(e.target.value);
                                            if (touched.projectName) {
                                                setErrors(prev => ({ ...prev, projectName: validateProjectName(e.target.value) }));
                                            }
                                        }}
                                        onBlur={() => handleBlur('projectName')}
                                    />
                                    {touched.projectName && errors.projectName && (
                                        <div className="invalid-feedback">{errors.projectName}</div>
                                    )}
                                </div>

                                {/* Project Owner */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">
                                        Project Owner
                                    </label>
                                    <select
                                        className={`form-select ${touched.projectOwner && errors.projectOwner ? 'is-invalid' : ''}`}
                                        value={projectOwner}
                                        onChange={(e) => {
                                            setProjectOwner(e.target.value);
                                            if (touched.projectOwner) {
                                                setErrors(prev => ({ ...prev, projectOwner: validateOwner(e.target.value) }));
                                            }
                                        }}
                                        onBlur={() => handleBlur('projectOwner')}
                                    >
                                        <option value="">Select Project Owner</option>
                                        {owners.map(o => (
                                            <option key={o.userId} value={o.userId}>
                                                {o.name} ({o.emailId})
                                            </option>
                                        ))}
                                    </select>
                                    {touched.projectOwner && errors.projectOwner && (
                                        <div className="invalid-feedback">{errors.projectOwner}</div>
                                    )}
                                </div>

                                {/* Project Start Date */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">
                                        Project Start Date
                                    </label>
                                    <input
                                        type="date"
                                        className={`form-control ${touched.startDate && errors.startDate ? 'is-invalid' : ''}`}
                                        value={startDate}
                                        onChange={(e) => {
                                            setStartDate(e.target.value);
                                            if (touched.startDate || touched.endDate) {
                                                const dateErrs = validateDates(e.target.value, endDate);
                                                setErrors(prev => ({ ...prev, ...dateErrs }));
                                            }
                                        }}
                                        onBlur={() => handleBlur('startDate')}
                                    />
                                    {touched.startDate && errors.startDate && (
                                        <div className="invalid-feedback">{errors.startDate}</div>
                                    )}
                                </div>

                                {/* Project End Date */}
                                <div className="col-md-6">
                                    <label className="form-label text-muted small mb-1 fw-semibold">
                                        Project End Date
                                    </label>
                                    <input
                                        type="date"
                                        className={`form-control ${touched.endDate && errors.endDate ? 'is-invalid' : ''}`}
                                        value={endDate}
                                        onChange={(e) => {
                                            setEndDate(e.target.value);
                                            if (touched.startDate || touched.endDate) {
                                                const dateErrs = validateDates(startDate, e.target.value);
                                                setErrors(prev => ({ ...prev, ...dateErrs }));
                                            }
                                        }}
                                        onBlur={() => handleBlur('endDate')}
                                    />
                                    {touched.endDate && errors.endDate && (
                                        <div className="invalid-feedback">{errors.endDate}</div>
                                    )}
                                </div>
                            </div>

                            {/* Buttons Row matching PDF Page 6 */}
                            <div className="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                                <button
                                    type="submit"
                                    className="btn btn-warning px-4 fw-semibold text-uppercase"
                                    disabled={!isFormValid() || isSubmitting}
                                >
                                    {isSubmitting ? 'Creating...' : 'CREATE'}
                                </button>
                                <button
                                    type="button"
                                    className="btn btn-outline-secondary px-4 fw-semibold text-uppercase"
                                    onClick={handleReset}
                                    disabled={isSubmitting}
                                >
                                    RESET
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CreateProjectForm;
