import { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import User from "../model/User";
import { registerUser } from "../services/userService";

/**
 * UserSignupForm - UnControlled Component Form
 * As required by PDF Page 4:
 * - Uses 'UnControlled Component' forms (useRef hooks instead of form state)
 * - Name mandatory and validated to not be blank
 * - Email & Password required and format validated
 * - Profile image mandatory and validated for valid image URL string
 * - Role field required with 'Project Owner' and 'Assignee'
 * - Submit button disabled if form is invalid
 * - Validation messages shown when user interacts with fields
 * - Login link navigates to Login page
 */
function UserSignupForm() {
    // Uncontrolled component refs
    const nameRef = useRef();
    const emailRef = useRef();
    const passwordRef = useRef();
    const profileImageRef = useRef();
    const roleRef = useRef();

    // Validation errors & status state
    const [errors, setErrors] = useState({});
    const [touched, setTouched] = useState({});
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const navigate = useNavigate();

    // Image URL format validator
    const validateImageUrl = (url) => {
        if (!url || !url.trim()) return 'Profile image URL is mandatory.';
        try {
            const parsed = new URL(url);
            if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
                return 'Image URL must use http:// or https:// protocol.';
            }
        } catch {
            return 'Please enter a valid image URL in string format.';
        }
        return '';
    };

    // Field-level validator for uncontrolled inputs
    const validateField = (fieldName) => {
        let err = '';
        switch (fieldName) {
            case 'name':
                const nameVal = nameRef.current?.value || '';
                if (!nameVal.trim()) err = 'Name is mandatory and cannot be blank.';
                else if (nameVal.trim().length < 2) err = 'Name must be at least 2 characters.';
                break;
            case 'email':
                const emailVal = emailRef.current?.value || '';
                if (!emailVal.trim()) err = 'Email address is required.';
                else if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(emailVal.trim())) {
                    err = 'Please provide a valid email format.';
                }
                break;
            case 'password':
                const passVal = passwordRef.current?.value || '';
                if (!passVal) err = 'Password is required.';
                else if (passVal.length < 6) err = 'Password must be at least 6 characters.';
                break;
            case 'profileImage':
                const imgVal = profileImageRef.current?.value || '';
                err = validateImageUrl(imgVal);
                break;
            case 'role':
                const roleVal = roleRef.current?.value || '';
                if (!roleVal) err = 'Please select a role.';
                break;
            default:
                break;
        }
        return err;
    };

    // On blur of each input, validate and update state
    const handleBlur = (fieldName) => {
        setTouched(prev => ({ ...prev, [fieldName]: true }));
        const err = validateField(fieldName);
        setErrors(prev => ({ ...prev, [fieldName]: err }));
    };

    // Re-check validity dynamically on change
    const handleChange = (fieldName) => {
        if (touched[fieldName]) {
            const err = validateField(fieldName);
            setErrors(prev => ({ ...prev, [fieldName]: err }));
        }
    };

    // Check overall form validity
    const isFormValid = () => {
        const nameVal = nameRef.current?.value || '';
        const emailVal = emailRef.current?.value || '';
        const passVal = passwordRef.current?.value || '';
        const imgVal = profileImageRef.current?.value || '';
        const roleVal = roleRef.current?.value || '';

        return (
            nameVal.trim() !== '' &&
            emailVal.trim() !== '' &&
            passVal !== '' &&
            imgVal.trim() !== '' &&
            roleVal !== '' &&
            !validateField('name') &&
            !validateField('email') &&
            !validateField('password') &&
            !validateField('profileImage') &&
            !validateField('role')
        );
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        const fieldNames = ['name', 'email', 'password', 'profileImage', 'role'];
        const allErrors = {};
        const allTouched = {};

        fieldNames.forEach(field => {
            allTouched[field] = true;
            const err = validateField(field);
            if (err) allErrors[field] = err;
        });

        setTouched(allTouched);
        setErrors(allErrors);

        if (Object.keys(allErrors).length > 0) {
            setError('Please correct the validation errors in the form.');
            return;
        }

        setIsSubmitting(true);
        try {
            const rawRole = roleRef.current.value;
            const normalizedRole = rawRole === 'Project Owner' ? 'PROJECT_OWNER' : 'ASSIGNEE';

            const newUser = new User(
                null,
                nameRef.current.value.trim(),
                emailRef.current.value.trim(),
                passwordRef.current.value,
                normalizedRole,
                profileImageRef.current.value.trim()
            );

            await registerUser(newUser);
            setSuccess('User registered successfully! Redirecting to login...');

            // Clear inputs
            e.target.reset();
            setErrors({});
            setTouched({});

            setTimeout(() => {
                navigate('/login');
            }, 1800);
        } catch (err) {
            console.error('Registration failed:', err);
            setError(err.message || 'An error occurred during registration. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light py-5">
            <div className="col-11 col-sm-9 col-md-6 col-lg-4">
                <div className="card shadow border-0" style={{ borderRadius: '8px', overflow: 'hidden' }}>
                    {/* Header banner matching PDF Page 4 */}
                    <div className="auth-header-banner">
                        Issue Tracking System
                    </div>

                    <div className="card-body p-4 bg-white">
                        <h4 className="text-center mb-4 fw-normal text-secondary">Signup</h4>

                        {error && (
                            <div className="alert alert-danger py-2" role="alert">
                                {error}
                            </div>
                        )}
                        {success && (
                            <div className="alert alert-success py-2" role="alert">
                                {success}
                            </div>
                        )}

                        <form onSubmit={handleSubmit} noValidate>
                            {/* Name Field */}
                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Name</label>
                                <input
                                    type="text"
                                    className={`form-control ${touched.name && errors.name ? 'is-invalid' : ''}`}
                                    placeholder="Enter name"
                                    ref={nameRef}
                                    onBlur={() => handleBlur('name')}
                                    onChange={() => handleChange('name')}
                                />
                                {touched.name && errors.name && (
                                    <div className="invalid-feedback">{errors.name}</div>
                                )}
                            </div>

                            {/* Email Address */}
                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Email address</label>
                                <input
                                    type="email"
                                    className={`form-control ${touched.email && errors.email ? 'is-invalid' : ''}`}
                                    placeholder="Enter email"
                                    ref={emailRef}
                                    onBlur={() => handleBlur('email')}
                                    onChange={() => handleChange('email')}
                                />
                                {touched.email && errors.email && (
                                    <div className="invalid-feedback">{errors.email}</div>
                                )}
                            </div>

                            {/* Password */}
                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Password</label>
                                <input
                                    type="password"
                                    className={`form-control ${touched.password && errors.password ? 'is-invalid' : ''}`}
                                    placeholder="Password"
                                    ref={passwordRef}
                                    onBlur={() => handleBlur('password')}
                                    onChange={() => handleChange('password')}
                                />
                                {touched.password && errors.password && (
                                    <div className="invalid-feedback">{errors.password}</div>
                                )}
                            </div>

                            {/* Profile Image URL */}
                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Profile</label>
                                <input
                                    type="url"
                                    className={`form-control ${touched.profileImage && errors.profileImage ? 'is-invalid' : ''}`}
                                    placeholder="Provide profile image url"
                                    ref={profileImageRef}
                                    onBlur={() => handleBlur('profileImage')}
                                    onChange={() => handleChange('profileImage')}
                                />
                                {touched.profileImage && errors.profileImage && (
                                    <div className="invalid-feedback">{errors.profileImage}</div>
                                )}
                            </div>

                            {/* Role Select Dropdown */}
                            <div className="mb-4">
                                <label className="form-label text-muted small mb-1">Role:</label>
                                <select
                                    className={`form-select ${touched.role && errors.role ? 'is-invalid' : ''}`}
                                    ref={roleRef}
                                    onBlur={() => handleBlur('role')}
                                    onChange={() => handleChange('role')}
                                    defaultValue=""
                                >
                                    <option value="">Select your role</option>
                                    <option value="Project Owner">Project Owner</option>
                                    <option value="Assignee">Assignee</option>
                                </select>
                                {touched.role && errors.role && (
                                    <div className="invalid-feedback">{errors.role}</div>
                                )}
                            </div>

                            {/* Submit Button - Disabled if form is invalid */}
                            <button
                                type="submit"
                                className="btn btn-brand w-100 py-2 mb-3 shadow-sm"
                                disabled={!isFormValid() || isSubmitting}
                            >
                                {isSubmitting ? 'Registering...' : 'Signup'}
                            </button>

                            {/* Link to Login */}
                            <div className="text-center mt-3">
                                <span className="text-muted small">Already have an account? </span>
                                <Link to="/login" className="text-primary text-decoration-none small fw-semibold">
                                    Login
                                </Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default UserSignupForm;
