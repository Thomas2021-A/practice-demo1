/**
 * User Model Class
 * Represents a user entity in the Issue Tracking System
 * Follows the ES6 class model structure taught in training
 */
class User {
    constructor(userId = null, name = '', emailId = '', password = '', role = 'ASSIGNEE', profileImage = '') {
        this.userId = userId;
        this.name = name;
        this.emailId = emailId;
        this.password = password;
        this.role = role;
        this.profileImage = profileImage;
    }
}

export default User;
