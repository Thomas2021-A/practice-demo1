/**
 * Project Model Class
 * Represents a project entity in the Issue Tracking System
 */
class Project {
    constructor(id = null, projectName = '', projectOwner = null, startDate = '', endDate = '') {
        this.id = id;
        this.projectName = projectName;
        this.projectOwner = projectOwner;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}

export default Project;
