import axios from "axios";
import { getStoredProjects, saveStoredProjects, getStoredIssues } from "./mockData";

// API Gateway route for ProjectServiceMS (or direct service on port 7003)
export const PROJECT_API_URL = 'http://localhost:9000/api/projects';

/**
 * Fetch all projects
 */
export const getAllProjects = async () => {
    try {
        const response = await axios.get(PROJECT_API_URL);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, returning mock projects:', error.message);
        return getStoredProjects();
    }
};

/**
 * Fetch projects owned by a specific project owner
 * @param {number} ownerId - The user ID of the project owner
 */
export const getProjectsByOwner = async (ownerId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/owner/${ownerId}`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, filtering mock projects by owner:', error.message);
        const projects = getStoredProjects();
        return projects.filter(p => Number(p.projectOwner) === Number(ownerId));
    }
};

/**
 * Fetch a single project by ID
 * @param {number} projectId
 */
export const getProjectById = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, finding project in mock store:', error.message);
        const projects = getStoredProjects();
        return projects.find(p => Number(p.id) === Number(projectId)) || null;
    }
};

/**
 * Create a new project
 * @param {Object} project - { projectName, projectOwner, startDate, endDate }
 */
export const createProject = async (project) => {
    try {
        const response = await axios.post(PROJECT_API_URL, project);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, creating project in mock store:', error.message);
        const projects = getStoredProjects();
        const newProject = {
            id: projects.length > 0 ? Math.max(...projects.map(p => p.id || 0)) + 1 : 1,
            projectName: project.projectName,
            projectOwner: Number(project.projectOwner),
            startDate: project.startDate,
            endDate: project.endDate
        };
        projects.push(newProject);
        saveStoredProjects(projects);
        return `Project created successfully with ID: ${newProject.id}`;
    }
};

/**
 * Update an existing project
 */
export const updateProject = async (id, project) => {
    try {
        const response = await axios.put(`${PROJECT_API_URL}/${id}`, project);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, updating project in mock store:', error.message);
        const projects = getStoredProjects();
        const index = projects.findIndex(p => Number(p.id) === Number(id));
        if (index !== -1) {
            projects[index] = { ...projects[index], ...project };
            saveStoredProjects(projects);
        }
        return `Project updated successfully for ID: ${id}`;
    }
};

/**
 * Delete a project
 */
export const deleteProject = async (id) => {
    try {
        const response = await axios.delete(`${PROJECT_API_URL}/${id}`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, deleting project from mock store:', error.message);
        const projects = getStoredProjects().filter(p => Number(p.id) !== Number(id));
        saveStoredProjects(projects);
        return `Project deleted successfully with ID: ${id}`;
    }
};

/**
 * Fetch issues belonging to a specific project
 * @param {number} projectId
 */
export const getIssuesByProjectId = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}/issues`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, filtering mock issues by project:', error.message);
        const issues = getStoredIssues();
        return issues.filter(i => Number(i.project) === Number(projectId));
    }
};
