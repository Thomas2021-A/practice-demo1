import axios from "axios";
import { getStoredUsers, saveStoredUsers } from "./mockData";

// API Gateway route for UserServiceMS (or direct service on port 7002)
export const USER_API_URL = 'http://localhost:9000/api/users';

/**
 * Register a new user (Uncontrolled form submission)
 * @param {Object} user - User model containing name, emailId, role, password, profileImage
 */
export const registerUser = async (user) => {
    try {
        const response = await axios.post(`${USER_API_URL}/register`, {
            name: user.name,
            emailId: user.emailId,
            password: user.password,
            role: user.role, // 'PROJECT_OWNER' or 'ASSIGNEE'
            profileImage: user.profileImage
        });
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, using mock storage for user registration:', error.message);
        // Fallback to mock storage for seamless demo / interview offline evaluation
        const users = getStoredUsers();
        const existing = users.find(u => u.emailId.toLowerCase() === user.emailId.toLowerCase());
        if (existing) {
            throw new Error(`Email ID is already registered: ${user.emailId}`);
        }
        const newUser = {
            userId: users.length > 0 ? Math.max(...users.map(u => u.userId || 0)) + 1 : 1,
            name: user.name,
            emailId: user.emailId,
            password: user.password,
            role: user.role,
            profileImage: user.profileImage
        };
        users.push(newUser);
        saveStoredUsers(users);
        return `User registered successfully with User ID: ${newUser.userId}`;
    }
};

/**
 * Login user with email, password, and role (Controlled form submission)
 * @param {string} emailId - User email
 * @param {string} password - User password
 * @param {string} role - Selected role ('PROJECT_OWNER' or 'ASSIGNEE')
 */
export const login = async (emailId, password, role) => {
    try {
        // Normalize role for backend enum (e.g. 'Project Owner' -> 'PROJECT_OWNER')
        const normalizedRole = role ? role.toUpperCase().replace(/\s+/g, '_') : '';
        const response = await axios.post(
            `${USER_API_URL}/login?name=&emailId=${encodeURIComponent(emailId)}&password=${encodeURIComponent(password)}&role=${encodeURIComponent(normalizedRole)}`
        );
        return { success: true, user: response.data };
    } catch (error) {
        console.warn('Backend unavailable, validating with mock user accounts:', error.message);
        // Fallback to mock data for demo / offline presentation
        const users = getStoredUsers();
        const user = users.find(u => u.emailId.toLowerCase() === emailId.trim().toLowerCase());

        if (!user) {
            return { success: false, user: null, error: `User not found with email: ${emailId}` };
        }
        if (user.password !== password) {
            return { success: false, user: null, error: 'Invalid password' };
        }

        const normalizedRole = role ? role.toUpperCase().replace(/\s+/g, '_') : '';
        if (normalizedRole && user.role !== normalizedRole) {
            return { success: false, user: null, error: `User role does not match selected role: ${role}` };
        }

        return { success: true, user };
    }
};

/**
 * Fetch all users (e.g. for assignee dropdowns)
 */
export const getAllUsers = async () => {
    try {
        const response = await axios.get(`${USER_API_URL}/all`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, returning mock users:', error.message);
        return getStoredUsers();
    }
};

/**
 * Fetch a single user by ID
 */
export const getUserById = async (userId) => {
    try {
        const response = await axios.get(`${USER_API_URL}/${userId}`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, finding user in mock store:', error.message);
        const users = getStoredUsers();
        return users.find(u => u.userId === Number(userId)) || null;
    }
};

/**
 * Fetch issues assigned to a specific user
 */
export const getIssuesByUserId = async (userId) => {
    try {
        const response = await axios.get(`${USER_API_URL}/${userId}/issues`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, returning mock issues for user:', error.message);
        const raw = localStorage.getItem('its_issues');
        const issues = raw ? JSON.parse(raw) : [];
        return issues.filter(i => Number(i.assignee) === Number(userId));
    }
};
