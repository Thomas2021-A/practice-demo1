/**
 * Initial Mock Data
 * Perfectly mirrors the screenshots and requirements from the Deloitte UI specification PDF.
 * This ensures that if the backend microservices are offline (or during an interview demo),
 * all screens, counters, kanban boards, and validations render and function flawlessly.
 */

export const INITIAL_USERS = [
    {
        userId: 1,
        name: "Jack Finn",
        emailId: "jack@xyz.com",
        password: "password123",
        role: "PROJECT_OWNER",
        profileImage: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"
    },
    {
        userId: 2,
        name: "Antonia Christie",
        emailId: "antonia@xyz.com",
        password: "password123",
        role: "ASSIGNEE",
        profileImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150"
    },
    {
        userId: 3,
        name: "Agastya Murali",
        emailId: "agastya@xyz.com",
        password: "password123",
        role: "ASSIGNEE",
        profileImage: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150"
    },
    {
        userId: 4,
        name: "Nani Ghanta",
        emailId: "nani@xyz.com",
        password: "password123",
        role: "ASSIGNEE",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150"
    },
    {
        userId: 5,
        name: "Navya Sen",
        emailId: "navya@xyz.com",
        password: "password123",
        role: "ASSIGNEE",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150"
    }
];

export const INITIAL_PROJECTS = [
    {
        id: 1,
        projectName: "FedEx Courier Service",
        projectOwner: 1,
        startDate: "2025-05-30",
        endDate: "2025-06-17"
    },
    {
        id: 2,
        projectName: "Stark Payment Gateway",
        projectOwner: 1,
        startDate: "2025-06-01",
        endDate: "2025-07-01"
    },
    {
        id: 3,
        projectName: "Deloitte Cloud Platform",
        projectOwner: 1,
        startDate: "2025-06-10",
        endDate: "2025-07-20"
    }
];

export const INITIAL_ISSUES = [
    {
        id: 11,
        summary: "Add delivery time estimation",
        description: "Implement a feature to show estimated delivery time for each shipment.",
        project: 1,
        assignee: 3,
        createdBy: 1,
        createdOn: "2025-06-10",
        lastUpdated: "2025-06-10 | 05:30",
        sprint: "2",
        storyPoint: 5,
        tags: "#delivery #feature",
        priority: "MEDIUM",
        status: "TO_DO",
        type: "TASK"
    },
    {
        id: 14,
        summary: "Integrate SMS delivery alerts",
        description: "Send automated SMS notifications on every delivery status update.",
        project: 1,
        assignee: 3,
        createdBy: 1,
        createdOn: "2025-06-10",
        lastUpdated: "2025-06-10 | 06:15",
        sprint: "2",
        storyPoint: 3,
        tags: "#sms #alerts",
        priority: "LOW",
        status: "TO_DO",
        type: "TASK"
    },
    {
        id: 13,
        summary: "Incorrect address validation",
        description: "Some valid addresses are being flagged as invalid during shipment creation.",
        project: 1,
        assignee: 4,
        createdBy: 1,
        createdOn: "2025-06-10",
        lastUpdated: "2025-06-10 | 08:00",
        sprint: "1",
        storyPoint: 2,
        tags: "#validation #bug",
        priority: "LOW",
        status: "DEVELOPMENT",
        type: "BUG"
    },
    {
        id: 15,
        summary: "Add bulk shipment upload",
        description: "Allow users to upload CSV file with multiple shipments at once.",
        project: 1,
        assignee: 4,
        createdBy: 1,
        createdOn: "2025-06-10",
        lastUpdated: "2025-06-10 | 09:30",
        sprint: "3",
        storyPoint: 7,
        tags: "#bulk #upload",
        priority: "MEDIUM",
        status: "DEVELOPMENT",
        type: "TASK"
    },
    {
        id: 16,
        summary: "Improve lost package reporting",
        description: "Improve lost package reporting form with photo attachment support.",
        project: 1,
        assignee: 5,
        createdBy: 1,
        createdOn: "2025-06-10",
        lastUpdated: "2025-06-10 | 11:45",
        sprint: "2",
        storyPoint: 5,
        tags: "#reporting",
        priority: "MEDIUM",
        status: "TESTING",
        type: "TASK"
    },
    {
        id: 10,
        summary: "Tracking number not updating",
        description: "Customers report that tracking numbers are not reflecting real-time updates.",
        project: 1,
        assignee: 3,
        createdBy: 1,
        createdOn: "2025-06-17",
        lastUpdated: "2025-06-17 | 14:20",
        sprint: "1",
        storyPoint: 3,
        tags: "#tracking #urgent",
        priority: "HIGH",
        status: "DONE",
        type: "BUG"
    },
    {
        id: 12,
        summary: "Schedule pickup request",
        description: "Allow customers to schedule pickup from their doorstep with custom time slot.",
        project: 1,
        assignee: 3,
        createdBy: 1,
        createdOn: "2025-06-10",
        lastUpdated: "2025-06-10 | 16:00",
        sprint: "2",
        storyPoint: 5,
        tags: "#pickup",
        priority: "LOW",
        status: "DONE",
        type: "TASK"
    },
    // Assignee (Antonia Christie) Issues as shown on Page 9 & 10 of PDF
    {
        id: 2,
        summary: "Login button not responsive",
        description: "Users report the login button does not respond on click. Needs urgent fix.",
        project: 1,
        assignee: 2,
        createdBy: 1,
        createdOn: "2025-06-11",
        lastUpdated: "2025-06-11 | 10:15",
        sprint: "1",
        storyPoint: 3,
        tags: "#login #UI",
        priority: "HIGH",
        status: "TO_DO",
        type: "BUG"
    },
    {
        id: 4,
        summary: "Display user balance",
        description: "Show current account balance on the main top navigation bar.",
        project: 1,
        assignee: 2,
        createdBy: 1,
        createdOn: "2025-06-11",
        lastUpdated: "2025-06-11 | 11:30",
        sprint: "1",
        storyPoint: 2,
        tags: "#balance #account",
        priority: "HIGH",
        status: "TO_DO",
        type: "TASK"
    },
    {
        id: 3,
        summary: "Add forgot password feature",
        description: "Implement a 'Forgot Password' link on the login screen.",
        project: 1,
        assignee: 2,
        createdBy: 1,
        createdOn: "2025-06-12",
        lastUpdated: "2025-06-12 | 15:00",
        sprint: "1",
        storyPoint: 3,
        tags: "#auth #password",
        priority: "MEDIUM",
        status: "DEVELOPMENT",
        type: "TASK"
    },
    {
        id: 1,
        summary: "Login App giving wrong message",
        description: "Login App giving wrong message: NO proper exception handling.",
        project: 1,
        assignee: 2,
        createdBy: 1,
        createdOn: "2025-06-16",
        lastUpdated: "2025-06-16 | 09:00",
        sprint: "1",
        storyPoint: 2,
        tags: "#auth #exception",
        priority: "HIGH",
        status: "DONE",
        type: "BUG"
    }
];

// Helper functions for mock storage
export const getStoredUsers = () => {
    const raw = localStorage.getItem('its_users');
    if (!raw) {
        localStorage.setItem('its_users', JSON.stringify(INITIAL_USERS));
        return INITIAL_USERS;
    }
    return JSON.parse(raw);
};

export const saveStoredUsers = (users) => {
    localStorage.setItem('its_users', JSON.stringify(users));
};

export const getStoredProjects = () => {
    const raw = localStorage.getItem('its_projects');
    if (!raw) {
        localStorage.setItem('its_projects', JSON.stringify(INITIAL_PROJECTS));
        return INITIAL_PROJECTS;
    }
    return JSON.parse(raw);
};

export const saveStoredProjects = (projects) => {
    localStorage.setItem('its_projects', JSON.stringify(projects));
};

export const getStoredIssues = () => {
    const raw = localStorage.getItem('its_issues');
    if (!raw) {
        localStorage.setItem('its_issues', JSON.stringify(INITIAL_ISSUES));
        return INITIAL_ISSUES;
    }
    return JSON.parse(raw);
};

export const saveStoredIssues = (issues) => {
    localStorage.setItem('its_issues', JSON.stringify(issues));
};
