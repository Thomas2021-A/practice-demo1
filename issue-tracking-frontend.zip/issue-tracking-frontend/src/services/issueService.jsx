import axios from "axios";
import { getStoredIssues, saveStoredIssues } from "./mockData";

// API Gateway route for IssueServiceMS (or direct service on port 7004)
export const ISSUE_API_URL = 'http://localhost:9000/api/issues';

/**
 * Fetch all issues
 */
export const getAllIssues = async () => {
    try {
        const response = await axios.get(ISSUE_API_URL);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, returning mock issues:', error.message);
        return getStoredIssues();
    }
};

/**
 * Fetch a single issue by its ID
 * @param {number} id
 */
export const getIssueById = async (id) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/${id}`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, finding issue in mock store:', error.message);
        const issues = getStoredIssues();
        return issues.find(i => Number(i.id) === Number(id)) || null;
    }
};

/**
 * Fetch issues by Project ID
 * @param {number} projectId
 */
export const getIssuesByProjectId = async (projectId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/project/${projectId}`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, filtering mock issues by project:', error.message);
        const issues = getStoredIssues();
        return issues.filter(i => Number(i.project) === Number(projectId));
    }
};

/**
 * Fetch issues by Project Owner (creator) ID
 * @param {number} ownerId
 */
export const getIssuesByOwnerId = async (ownerId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/owner/${ownerId}`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, filtering mock issues by owner:', error.message);
        const issues = getStoredIssues();
        return issues.filter(i => Number(i.createdBy) === Number(ownerId));
    }
};

/**
 * Fetch issues assigned to an Assignee
 * @param {number} assigneeId
 */
export const getIssuesByAssigneeId = async (assigneeId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/assignee/${assigneeId}`);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, filtering mock issues by assignee:', error.message);
        const issues = getStoredIssues();
        return issues.filter(i => Number(i.assignee) === Number(assigneeId));
    }
};

/**
 * Create a new issue
 * @param {Object} issue
 */
export const createIssue = async (issue) => {
    try {
        const response = await axios.post(ISSUE_API_URL, issue);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, creating issue in mock store:', error.message);
        const issues = getStoredIssues();
        const now = new Date();
        const formattedDate = `${String(now.getDate()).padStart(2, '0')}-${String(now.getMonth() + 1).padStart(2, '0')}-${now.getFullYear()}`;
        const newIssue = {
            id: issues.length > 0 ? Math.max(...issues.map(i => i.id || 0)) + 1 : 1,
            summary: issue.summary,
            description: issue.description || '',
            project: Number(issue.project),
            assignee: Number(issue.assignee),
            createdBy: Number(issue.createdBy),
            createdOn: formattedDate,
            lastUpdated: `${formattedDate} | ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
            sprint: String(issue.sprint),
            storyPoint: Number(issue.storyPoint),
            tags: issue.tags || '',
            priority: issue.priority,
            status: issue.status || 'TO_DO',
            type: issue.type || 'TASK'
        };
        issues.push(newIssue);
        saveStoredIssues(issues);
        return `Issue created successfully with Issue ID: ${newIssue.id}`;
    }
};

/**
 * Update an existing issue
 * @param {number} id
 * @param {Object} issue
 */
export const updateIssue = async (id, issue) => {
    try {
        const response = await axios.put(`${ISSUE_API_URL}/${id}`, issue);
        return response.data;
    } catch (error) {
        console.warn('Backend unavailable, updating issue in mock store:', error.message);
        const issues = getStoredIssues();
        const index = issues.findIndex(i => Number(i.id) === Number(id));
        if (index !== -1) {
            const now = new Date();
            const formattedDate = `${String(now.getDate()).padStart(2, '0')}-${String(now.getMonth() + 1).padStart(2, '0')}-${now.getFullYear()}`;
            issues[index] = {
                ...issues[index],
                ...issue,
                lastUpdated: `${formattedDate} | ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`
            };
            saveStoredIssues(issues);
        }
        return `Issue details updated successfully for ID: ${id}`;
    }
};
