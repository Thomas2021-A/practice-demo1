import { createContext, useEffect, useState } from "react";

/**
 * Authentication Context
 * Manages user login state, stored user details, and provides
 * ctxLogin and ctxLogout helpers across the application.
 */
export const AuthContext = createContext();

export function AuthProvider({ children }) {
    // Initialize logged in state from localStorage
    const [isLoggedIn, setIsLoggedIn] = useState(() => {
        const stored = localStorage.getItem('isLoggedIn');
        return stored === 'true';
    });

    // Initialize user object from localStorage
    const [user, setUser] = useState(() => {
        const stored = localStorage.getItem('user');
        try {
            return stored ? JSON.parse(stored) : null;
        } catch {
            return null;
        }
    });

    // Synchronize auth state with localStorage whenever it changes
    useEffect(() => {
        localStorage.setItem('isLoggedIn', isLoggedIn ? 'true' : 'false');
        if (user) {
            localStorage.setItem('user', JSON.stringify(user));
        } else {
            localStorage.removeItem('user');
        }
    }, [isLoggedIn, user]);

    // Login handler
    const ctxLogin = (userData) => {
        setIsLoggedIn(true);
        setUser(userData);
    };

    // Logout handler
    const ctxLogout = () => {
        setIsLoggedIn(false);
        setUser(null);
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('user');
    };

    return (
        <AuthContext.Provider value={{ isLoggedIn, user, ctxLogin, ctxLogout }}>
            {children}
        </AuthContext.Provider>
    );
}
