import { useContext } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import { AuthContext } from './context/AuthContext';
import UserLoginForm from './components/UserLoginForm';
import UserSignupForm from './components/UserSignupForm';
import ProjectOwnerDashboard from './components/ProjectOwnerDashboard';
import CreateProjectForm from './components/CreateProjectForm';
import CreateIssueForm from './components/CreateIssueForm';
import IssueDetails from './components/IssueDetails';
import EditIssueForm from './components/EditIssueForm';
import AssigneeDashboard from './components/AssigneeDashboard';
import AssigneeIssueDetails from './components/AssigneeIssueDetails';

/**
 * Protected Route wrapper for authenticated users
 */
function ProtectedRoute({ children, allowedRole }) {
    const { isLoggedIn, user } = useContext(AuthContext);

    if (!isLoggedIn || !user) {
        return <Navigate to="/login" replace />;
    }

    if (allowedRole) {
        const userRole = (user.role || '').toUpperCase().replace(/\s+/g, '_');
        const requiredRole = allowedRole.toUpperCase().replace(/\s+/g, '_');

        if (userRole !== requiredRole) {
            // Redirect to appropriate dashboard based on their actual role
            if (userRole === 'PROJECT_OWNER') {
                return <Navigate to="/project-dashboard" replace />;
            } else {
                return <Navigate to="/assignee-dashboard" replace />;
            }
        }
    }

    return children;
}

/**
 * Root / default redirect handler
 */
function RootRedirect() {
    const { isLoggedIn, user } = useContext(AuthContext);

    if (!isLoggedIn || !user) {
        return <Navigate to="/login" replace />;
    }

    const userRole = (user.role || '').toUpperCase().replace(/\s+/g, '_');
    if (userRole === 'PROJECT_OWNER') {
        return <Navigate to="/project-dashboard" replace />;
    } else {
        return <Navigate to="/assignee-dashboard" replace />;
    }
}

function App() {
    return (
        <div className="App">
            <Routes>
                {/* Default route */}
                <Route path="/" element={<RootRedirect />} />

                {/* Authentication Routes */}
                <Route path="/login" element={<UserLoginForm />} />
                <Route path="/signup" element={<UserSignupForm />} />

                {/* Project Owner Routes */}
                <Route
                    path="/project-dashboard"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <ProjectOwnerDashboard />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/create-project"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <CreateProjectForm />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/create-issue"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <CreateIssueForm />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/issue-details/:issueId"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <IssueDetails />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/edit-issue/:issueId"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <EditIssueForm />
                        </ProtectedRoute>
                    }
                />

                {/* Assignee Routes */}
                <Route
                    path="/assignee-dashboard"
                    element={
                        <ProtectedRoute allowedRole="ASSIGNEE">
                            <AssigneeDashboard />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/assignee-issue-details/:issueId"
                    element={
                        <ProtectedRoute allowedRole="ASSIGNEE">
                            <AssigneeIssueDetails />
                        </ProtectedRoute>
                    }
                />

                {/* Catch-all redirect */}
                <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
        </div>
    );
}

export default App;
